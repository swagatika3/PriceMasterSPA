import { ComponentFixture, TestBed } from '@angular/core/testing';
import { EMPTY, of, throwError } from 'rxjs';
import { SplDtoMock } from '../../mock/models/spl-dto.model.mock';
import { SplNumberDtoMock } from '../../mock/models/spl-number-dto.model.mock';
import { SplDto } from '../../models/spl-dto.model';
import { SplNumberDto } from '../../models/spl-number-dto.model';
import { AccountIdCloneDialogComponent } from './account-id-clone-dialog.component';

describe('AccountIdCloneDialogComponent', () => {
  let component: AccountIdCloneDialogComponent;
  let routerMock: any
  let splCreateServiceMock: any;
  let splServiceMock: any;

  const mockSplDto: SplDto = new SplDtoMock()
    .withAccountId(2252)
    .withSplName('SPL_1')
    .withEffectiveDate(new Date())
    .withSplYear(2022)
    .withSplCategoryDtos([{ categoryId: 1, appliedDiscount: 0 }])
    .model();
  const splNumberDto: SplNumberDto = new SplNumberDtoMock()
    .withSplNumber(35956)
    .model();

  beforeAll(() => {
    routerMock = {
      navigate: jest.fn()
    };

    splCreateServiceMock = {
      getSplNumberByCloneSpl: jest.fn().mockReturnValue(of(123456))
      // getSplNumberByCloneSpl: jest.fn().mockReturnValue(splNumberDto),
    }

    splServiceMock = {
      splDto: mockSplDto,
      cloneSpl: jest.fn().mockReturnValue(of(123456))
    }
    component = new AccountIdCloneDialogComponent(routerMock, splCreateServiceMock, splServiceMock);
  });


  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('cloneSpl', () => {
    it('should test cloneSpl', () => {
      let navigateSpy = jest.spyOn(splCreateServiceMock, 'getSplNumberByCloneSpl');
      let splNumber = 45;
      component.accountId = '44947';
      component.cloneSpl();
      expect(navigateSpy).toHaveBeenCalled();
    });

    it('should test cloneSpl method for any exception', () => {
      const error = {
        status: 401,
        message: 'Unable to find any active SPLs for the account number',
        error: 'Exception: Unable to find any active SPLs for the account number',
      }
      let spy = jest.spyOn(splCreateServiceMock, 'getSplNumberByCloneSpl').mockImplementation(() => { return throwError(error); });
      jest.spyOn(window, 'alert').mockImplementation(() => of(EMPTY));
      component.accountId = '44947';
      component.cloneSpl();
      expect(window.alert).toBeCalledWith('Unable to find any active SPLs for the account number ');
    });

    it('should test cloneSpl method for any exception', () => {
      const error1 = {
        status: 401,
        message: 'Account ID does not exist',
        error: 'System.ArgumentException: Account ID does not exist',
      }
      component.accountId = '44947';
      let spy = jest.spyOn(splCreateServiceMock, 'getSplNumberByCloneSpl').mockImplementation(() => { return throwError(error1); });
      jest.spyOn(window, 'alert').mockImplementation(() => of('Account ID does not exist'));
      component.cloneSpl();
      expect(spy).toHaveBeenCalled();
      expect(window.alert).toBeCalledWith('Unable to find any active SPLs for the account number ');
      // expect(window.alert).toBeCalledWith('Account ID does not exist');
    });

    it('should test cloneSpl method for any exception', () => {
      const error1 = {
        status: 401,
        message: 'some unknown error',
        error: 'some unknown error',
      }
      component.accountId = '44948';
      jest.spyOn(splCreateServiceMock, 'getSplNumberByCloneSpl').mockImplementation(() => { return throwError(error1); });
      jest.spyOn(window, 'alert').mockImplementation(() => of(EMPTY));
      component.cloneSpl();
      expect(window.alert).toBeCalledWith('Unable to find any active SPLs for the account number ');
    });

  });


});
