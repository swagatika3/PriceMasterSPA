import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import { SplCreateService } from '../../services/spl-create.service';
import { SplService } from '../../services/spl.service';

@Component({
  selector: 'app-account-id-clone-dialog',
  templateUrl: './account-id-clone-dialog.component.html',
  styleUrls: ['./account-id-clone-dialog.component.scss']
})
export class AccountIdCloneDialogComponent {
  @Input('dialog') dialog = { show: false }
  accountId = '';

  constructor(
    private router: Router,
    private splCreateService: SplCreateService,
    public splService: SplService
  ) { }

  cloneSpl(): void {
    this.dialog.show = false;
    this.splCreateService.getSplNumberByCloneSpl(Number(this.accountId), this.splService.splDto.accountId).subscribe(splNumberDto => {
      this.router.navigate(['/spl', splNumberDto.splNumber]);
    }, error => {
      this.accountId = '';
      if (error.error.toString().indexOf('Unable to find any active SPLs for the account number') != 0)
        alert(`Unable to find any active SPLs for the account number ${this.accountId}`);
      else if (error.error.toString().indexOf('does not exist') != 0)
        alert('Account ID does not exist');
      else
        alert('Error occured. Please try again.');
    });
  }
}
