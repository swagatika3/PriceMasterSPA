import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { SplCreateComponent } from './components/spl-create/spl-create.component';
import { SplEditComponent } from './components/spl-edit/spl-edit.component';

const routes: Routes = [
  // The ID used by the SplCreateComponent is the AccountId
  { path: 'spl-new/:id', component: SplCreateComponent },
  // The ID used by the SplEditComponent is the SPL Number
  { path: 'spl/:id', component: SplEditComponent },
  { path: '', component: HomeComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
