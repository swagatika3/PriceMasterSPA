import { Component } from '@angular/core';
import { SplService } from '../../../services/spl.service';

@Component({
  selector: 'app-projections',
  templateUrl: './projections.component.html',
  styleUrls: ['./projections.component.scss']
})

export class ProjectionsComponent {
  constructor(public splService: SplService) { }
}
