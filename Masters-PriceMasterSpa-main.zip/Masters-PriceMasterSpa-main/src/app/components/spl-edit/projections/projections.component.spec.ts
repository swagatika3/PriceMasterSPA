import { ProjectionsComponent } from './projections.component';

describe('ProjectionsComponent', () => {
  let component: ProjectionsComponent;
  let splServiceMock: any;

  beforeEach(() => {
    splServiceMock = {};

    component = new ProjectionsComponent(splServiceMock);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
