import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { SplDto } from '../../../models/spl-dto.model';
import { SplNumberDto } from '../../../models/spl-number-dto.model';
import { SplService } from '../../../services/spl.service';
import { ConfigService } from '../../../services/config.service';
import { SplMode } from '../../../enums/splmode.enum';
import { Router } from '@angular/router';

@Component({
  selector: 'app-spl-footer',
  templateUrl: './spl-footer.component.html',
  styleUrls: ['./spl-footer.component.scss']
})
export class SplFooterComponent implements OnInit {

  
  disableSaveAsDraft = false;
  disableSubmit = false;
  splNumber = 0;
  splDtoBackup: SplDto = new SplDto();
  SplDtoBackupIsReady = false;
  saveConfirmationModal = { show: false, };
  isSaveCompleted = false;
  private splDetailsBasedOnSplNumberIsReadySubscription!: Subscription;
  
  constructor(private splService: SplService,private configService: ConfigService,private router: Router) {
   }

  ngOnInit(): void {
    this.splDetailsBasedOnSplNumberIsReadySubscription = this.splService.splDetailsBasedOnSplNumberIsReady.subscribe(() => {
      
      if(this.SplDtoBackupIsReady === false)
      {
        this.splDtoBackup = JSON.parse(JSON.stringify(this.splService.splDto)) as SplDto;
        this.SplDtoBackupIsReady = true;
      }
     
      this.disableSaveAsDraft = this.splService.splDto.statusCode === 'A' || this.splService.splDto.statusCode === 'P' ? true : false;
      this.disableSubmit = this.splService.splDto.statusCode === 'P' ? true : false;
    });

  }

  clickSubmit():void{
   if(this.splService.splDto.statusCode === 'D')
   this.splService.splDto.statusCode = 'P';
   this.saveSpl();
  }
  clickSaveAsDraft():void{
    this.saveSpl();
    
  }
  clickCancel():void{
    if(this.configService.splMode === SplMode.CreateNextYearSpl || this.configService.splMode === SplMode.EditSpl)
    {
      window.close();
    }
    else if(this.configService.splMode === SplMode.CreateSpl)
    {
      this.splService.splDto = JSON.parse(JSON.stringify(this.splDtoBackup)) as SplDto;
      this.router.navigate(['/spl-new', this.splService.splDto.accountId]);

    }
  }
  okDialog(){
    this.saveConfirmationModal.show=false;
    window.close();
  }
  saveSpl(): void {
    

    this.splService.saveSpl(this.splService.splDto).subscribe((data: SplNumberDto) => {
      this.splNumber = data.splNumber;
      this.saveConfirmationModal.show = true;
      this.isSaveCompleted = true;
    }, (error: Error) => {
      console.log(error);
      alert('Unable to save Spl');
    });
  }
  ngOnDestroy(): void {
    this.splDetailsBasedOnSplNumberIsReadySubscription?.unsubscribe();
  }

}
