
import { EMPTY, of, Subject } from 'rxjs';
import { SplMode } from '../../../enums/splmode.enum';
import { SplDtoMock } from '../../../mock/models/spl-dto.model.mock';
import { SplDto } from '../../../models/spl-dto.model';
import { SplFooterComponent } from './spl-footer.component';

describe('SplFooterComponent', () => {
  let component: SplFooterComponent;
  let mockSplService: any;
  let mockConfigService: any;
  let routerMock: any
  const splDetailsBasedOnSplNumberIsReadyMock = new Subject<SplDto>();
  //const mockAccountHeaderIsReady = new Subject<SplDto>();
  const mockSplDto: SplDto = new SplDtoMock()
  .withAccountId(1)
  .withSplName('SPL_1')
  .withEffectiveDate(new Date())
  .withSplYear(2022)
  .withStatusCode('P')
  .withSplCategoryDtos([{categoryId: 1, appliedDiscount: 0}])
  .model();

  beforeEach(() => {
    mockSplService = {
      
      splDetailsBasedOnSplNumberIsReady: splDetailsBasedOnSplNumberIsReadyMock,
      splDto : mockSplDto,
      saveSpl: jest.fn().mockReturnValue(of(mockSplDto,mockSplDto)),
      getSplDetailsBasedOnSplNumber:jest.fn().mockReturnValue(mockSplDto)
    }
    mockConfigService={
      splMode :SplMode.CreateNextYearSpl
    }
    routerMock = {
      navigate: jest.fn()
    };

    component = new SplFooterComponent(mockSplService,mockConfigService,routerMock);
  });
  it('should create', () => {
    component.saveConfirmationModal.show = false;
    component.isSaveCompleted = false;
    expect(component).toBeTruthy();
  });
  describe('Page Life Cycle Hooks', () => {
    it('should test ngOnInit', () => {
      component.ngOnInit();
      splDetailsBasedOnSplNumberIsReadyMock.next(mockSplDto);
      
       expect(component.disableSaveAsDraft).toEqual(true);

    });
    it('should unsubscribe when ngOnDestroy', () => {
      component['splDetailsBasedOnSplNumberIsReadySubscription'] = of().subscribe();
      const unsubscriptionSpy1 = jest.spyOn(component['splDetailsBasedOnSplNumberIsReadySubscription'], 'unsubscribe');
      component.ngOnDestroy();
      expect(unsubscriptionSpy1).toHaveBeenCalled();
     
    });
});
it('should test clickSubmit', () => {
  mockSplDto.statusCode = 'D';
  const spy1 = jest.spyOn(mockSplService, 'saveSpl');
  component.clickSubmit();
  expect(mockSplDto.statusCode).toEqual('P');
  expect(spy1).toHaveBeenCalled();
});
it('should test clickSaveAsDraft', () => {
  const spy1 = jest.spyOn(mockSplService, 'saveSpl');
  component.clickSaveAsDraft();
  expect(spy1).toHaveBeenCalled();
});
describe('should test clickCancel', () => {
it('should test clickCancel for CreateNextYearSPL', () => {
  jest.spyOn(window, 'close').mockImplementation(() => of(EMPTY));
  component.clickCancel();
});
it('should test clickCancel for CreateSPL', () => {
  jest.spyOn(window, 'close').mockImplementation(() => of(EMPTY));
  mockConfigService.splMode = SplMode.CreateSpl;
  component.clickCancel();
});
});
it('should test okDialog', () => {
  jest.spyOn(window, 'close').mockImplementation(() => of(EMPTY));
  component.okDialog();
  expect(component.saveConfirmationModal.show).toEqual(false);
 
});
});
