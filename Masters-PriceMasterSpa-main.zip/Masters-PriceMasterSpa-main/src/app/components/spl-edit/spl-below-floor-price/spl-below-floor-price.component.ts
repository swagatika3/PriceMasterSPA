import { Component } from '@angular/core';
import { SplService } from '../../../services/spl.service';

@Component({
  selector: 'app-spl-below-floor-price',
  templateUrl: './spl-below-floor-price.component.html',
  styleUrls: ['./spl-below-floor-price.component.scss']
})
export class SplBelowFloorPriceComponent {
  constructor(public splService: SplService) {
  }
}
