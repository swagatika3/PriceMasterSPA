import { ComponentFixture } from '@angular/core/testing';

import { SplBelowFloorPriceComponent } from './spl-below-floor-price.component';

describe('SplEditComponent', () => {
  let component: SplBelowFloorPriceComponent;
  let mockSplService: any;
  let fixture: ComponentFixture<SplBelowFloorPriceComponent>;

  beforeAll(() => {
  component = new SplBelowFloorPriceComponent(mockSplService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
