import { of, Subject } from 'rxjs';
import { SplApprovalDtoMock } from '../../../mock/models/spl-approval-dto.model.mock';
import { SplApprovalDto } from '../../../models/spl-approval-dto.model';
import { SplDto } from '../../../models/spl-dto.model';
import { ApprovalSectionComponent } from './approval-section.component';

describe('ApprovalSectionComponent', () => {
  let splServiceMock: any;
  let component: ApprovalSectionComponent;
  let splApprovalDtoMock: SplApprovalDto[];
  const splDetailsBasedOnSplNumberIsReadyMock = new Subject<SplDto>();

  beforeEach(() => {
    splApprovalDtoMock = [new SplApprovalDtoMock().model()];

    splServiceMock = {
      splDetailsBasedOnSplNumberIsReady: splDetailsBasedOnSplNumberIsReadyMock,
      getApprovals: jest.fn().mockImplementation(() => of(splApprovalDtoMock))
    };

    component = new ApprovalSectionComponent(splServiceMock);
  });

  it('should create ApprovalSectionComponent', () => {
    expect(component).toBeTruthy();
  });

  describe('ngOnInit', () => {
    it('should test ngOnInit', () => {
      component.ngOnInit();
      splDetailsBasedOnSplNumberIsReadyMock.next();
      expect(component).toBeTruthy();
    });
  });

  describe('setPanelForApprovalSection', () => {
    it('should test setPanelForApprovalSection with panel class as open', () => {
      component.approvalSectionPanelClass = 'uitk-l-grid-open';
      component.setPanelForApprovalSection();
      expect(component).toBeTruthy();
    });

    it('should test setPanelForApprovalSection with panel class as close', () => {
      component.approvalSectionPanelClass = 'uitk-l-grid1-close';
      component.setPanelForApprovalSection();
      expect(component).toBeTruthy();
    });
  });

  describe('ngOnDestroy', () => {
    it('should test ngOnDestroy', () => {
      component['splDetailsBasedOnSplNumberIsReadySubscription'] = of().subscribe();
      component.ngOnDestroy();
      expect(component).toBeTruthy();
    });
  });
});
