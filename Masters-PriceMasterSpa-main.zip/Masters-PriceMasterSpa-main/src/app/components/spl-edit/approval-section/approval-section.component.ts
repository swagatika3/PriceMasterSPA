import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { SplDto } from '../../../models/spl-dto.model';
import { SplService } from '../../../services/spl.service';
import { SplApprovalDto } from '../../../models/spl-approval-dto.model';

@Component({
  selector: 'app-approval-section',
  templateUrl: './approval-section.component.html',
  styleUrls: ['./approval-section.component.scss']
})

export class ApprovalSectionComponent implements OnInit, OnDestroy {
  private readonly _splService: SplService;
  private splDetailsBasedOnSplNumberIsReadySubscription!: Subscription;
  collapsibleApprovalSectionPanel = true;
  openApprovalSectionPanel = true;
  approvalSectionPanelClass = 'uitk-l-grid-open';
  splApprovalDetails: SplApprovalDto[] = [];
  splDto: SplDto = new SplDto();
  tableHeader = [
    { id: 1, name: 'Levels' },
    { id: 2, name: 'Assigned' },
    { id: 3, name: 'Approved By' },
    { id: 4, name: 'Status' },
    { id: 5, name: 'Date' }
  ];

  constructor(splService: SplService) {
    this._splService = splService;
  }

  ngOnInit(): void {
    this.splDetailsBasedOnSplNumberIsReadySubscription = this._splService.splDetailsBasedOnSplNumberIsReady.subscribe((data: SplDto) => {
      this._splService.getApprovals(data.id).subscribe((splApprovals: SplApprovalDto[]) => {
        this.splApprovalDetails = splApprovals;
      });

      this.splDto = data;
    });
  }

  setPanelForApprovalSection(): void {
    if (this.approvalSectionPanelClass === 'uitk-l-grid-open') {
      this.approvalSectionPanelClass = 'uitk-l-grid1-close';
    }
    else {
      this.approvalSectionPanelClass = 'uitk-l-grid-open';
    }
  }

  ngOnDestroy(): void {
    this.splDetailsBasedOnSplNumberIsReadySubscription.unsubscribe();
  }
}
