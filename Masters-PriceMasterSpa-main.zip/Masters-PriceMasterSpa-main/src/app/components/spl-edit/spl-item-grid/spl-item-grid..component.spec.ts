import { IUITKColumnState } from "@uitk/angular";
import { EMPTY, of, Subject } from "rxjs";
import { SplGridColumnDtoMock } from "../../../mock/models/spl-item-grid-column-dto.model.mock";
import { SplGridColumnDto } from "../../../models/spl-item-grid-column-dto.model";
import { OrderSummaryDtoMock } from "../../../mock/models/order-summary-dto.model.mock";
import { PriceCatalogDtoMock } from "../../../mock/models/price-catalog-dto.model.mock";
import { ProductDtoMock } from "../../../mock/models/product-dto.model.mock";
import { SplDtoMock } from "../../../mock/models/spl-dto.model.mock";
import { SplProductDtoMock } from "../../../mock/models/spl-product-dto.model.mock";
import { ProductDto } from "../../../models/product-dto.model";
import { SplDto } from "../../../models/spl-dto.model";
import { SplProductDto } from "../../../models/spl-product-dto.model";
import { SplItemGridComponent } from "./spl-item-grid.component";
import { UserGridPreferenceDto } from "../../../models/user-grid-preference-dto.model";
import { UserGridPreferenceDtoMock } from "../../../mock/models/user-grid-preference-dto.model.mock";
import { ColumnMock } from "../../../mock/models/column-dto.model.mock";
import { CategoryDto } from "../../../models/category-dto.model";
import { CategoryDtoMock } from "../../../mock/models/category-dto.model.mock";


describe('OrderComponent', () => {
  let component: SplItemGridComponent;
  let splServiceMock: any;
  let configServiceMock: any;
  let currencyPipeMock: any;
  let datePipeMock: any;
  const splDetailsBasedOnSplNumberIsReadyMock = new Subject();
  const productDtoMock: ProductDto[] = [new ProductDtoMock()
    .withProductId(1)
    .withCategoryId(123)
    .withProductCode("0045")
    .withDescription("Test data")
    .withMaxDiscountPercent(50)
    .withEffectiveDate(new Date('03/24/2022'))
    .model(), new ProductDtoMock()
      .withProductId(1)
      .withCategoryId(123)
      .withProductCode("0047")
      .withDescription("test")
      .withMaxDiscountPercent(50)
      .withEffectiveDate(new Date('03/24/2022'))
      .model()];
  let categoryDtoMock: CategoryDto[];

  const mockSplDto: SplDto = new SplDtoMock()
    .withAccountId(1)
    .withSplName('SPL_1')
    .withEffectiveDate(new Date())
    .withSplYear(2022)
    .withSplCategoryDtos([{ categoryId: 1, appliedDiscount: 0 }])
    .withSplProductDtos([new SplProductDtoMock()
      .withProductId(1)
      .withSplPrice(100)
      .withSplDiscount(10)
      .withEffectiveDate(new Date('02/12/2022'))
      .withCurrentProductDto(new ProductDtoMock()
        .withCategoryId(123)
        .withProductCode("0045")
        .withDescription("test")
        .withMaxDiscountPercent(50)
        .withEffectiveDate(new Date('03/24/2022'))
        .model())
      .model(), new SplProductDtoMock()
        .withSplPrice(100)
        .withSplDiscount(10)
        .withEffectiveDate(new Date('02/12/2022'))
        .model()])
    .model();
  let splProductDtosMock: SplProductDto[];
  let splGridColumnDtosMock: SplGridColumnDto[];
  let userGridPreferenceDtoMock: UserGridPreferenceDto;

  beforeEach(() => {
    categoryDtoMock = [new CategoryDtoMock()
      .withId(1)
      .withCategoryNumber('01')
      .withCategoryDescription('First Category')
      .model(),
    new CategoryDtoMock()
      .withId(2)
      .withCategoryNumber('02')
      .withCategoryDescription('Second Category')
      .model()
    ];
    splProductDtosMock = [new SplProductDtoMock()
      .withProductId(1)
      .withQuantity(10)
      .withSplDiscount(50)
      .withSplPrice(100)
      .withCurrentProductDto(new ProductDtoMock()
        .withProductCode("0045")
        .withDescription('test1')
        .withMaxDiscountPercent(50)
        .withEditionYear('2020')
        .withPriceCatalogDto(new PriceCatalogDtoMock()
          .withListPrice(10)
          .withFloorPrice(10)
          .withTargetPrice(10)
          .model())
        .withOrderSummaryDto(new OrderSummaryDtoMock()
          .withAverageDiscount(10)
          .withUnitsSold(10)
          .model())
        .model())
      .withAppliedCategoryDiscount(10)
      .withPriorProductDto(new ProductDtoMock()
        .withOrderSummaryDto(new OrderSummaryDtoMock()
          .withAverageDiscount(10)
          .withUnitsSold(10)
          .model())
        .model())
      .model(),
    new SplProductDtoMock()
      .withProductId(2)
      .withQuantity(20)
      .withSplDiscount(75)
      .withSplPrice(150)
      .withAppliedCategoryDiscount(20)
      .withCurrentProductDto(new ProductDtoMock()
        .withProductCode("0050")
        .withDescription('test2')
        .withMaxDiscountPercent(60)
        .withEditionYear('2021')
        .withPriceCatalogDto(new PriceCatalogDtoMock()
          .withListPrice(20)
          .withFloorPrice(20)
          .withTargetPrice(20)
          .model())
        .withOrderSummaryDto(new OrderSummaryDtoMock()
          .withAverageDiscount(20)
          .withUnitsSold(20)
          .model())
        .model())
      .withPriorProductDto(new ProductDtoMock()
        .withProductCode("0050")
        .withDescription('test2')
        .withMaxDiscountPercent(60)
        .withEditionYear('2021')
        .withPriceCatalogDto(new PriceCatalogDtoMock()
          .withListPrice(20)
          .withFloorPrice(20)
          .withTargetPrice(20)
          .model())
        .withOrderSummaryDto(new OrderSummaryDtoMock()
          .withAverageDiscount(20)
          .withUnitsSold(20)
          .model())
        .model())
      .model()
      ];

    splGridColumnDtosMock = [new SplGridColumnDtoMock()
      .withColumnId(1)
      .withFieldType('text')
      .withFormat('')
      .withFrozen(true)
      .withIsFieldDisabled(true)
      .withIsShown(true)
      .withName('test column 1')
      .withPosition(1)
      .withTitle('test column 1')
      .model(),
    new SplGridColumnDtoMock()
      .withColumnId(2)
      .withFieldType('span')
      .withFormat('')
      .withFrozen(false)
      .withIsFieldDisabled(false)
      .withIsShown(false)
      .withName('test column 2')
      .withPosition(2)
      .withTitle('test column 2')
      .model()];
    userGridPreferenceDtoMock = new UserGridPreferenceDtoMock()
      .withUserLogin('msunilk2')
      .withGridName('SplProductGrid')
      .withColumns([new ColumnMock()
        .withColumnName('test column 1')
        .withPosition(1)
        .model(),
      new ColumnMock()
        .withColumnName('test column 2')
        .withPosition(2)
        .model()])
      .model();

    splServiceMock = {
      splDto: mockSplDto,
      splProductDtos: splProductDtosMock,
      splDetailsBasedOnSplNumberIsReady: splDetailsBasedOnSplNumberIsReadyMock,
      getUserPreferences: jest.fn(),
      saveUserPreferences: jest.fn().mockReturnValue(of(userGridPreferenceDtoMock)),
      calculateSplPrice:jest.fn(),
      calculateItemsBelowFP:jest.fn()
    };

    configServiceMock = {
      productDtos: productDtoMock,
      categoryDtos: categoryDtoMock,
      getMyMSId: jest.fn().mockReturnValue("TestUser")
    };

    currencyPipeMock = {
      transform: jest.fn()
    };

    datePipeMock = {
      transform: jest.fn()
    }

    component = new SplItemGridComponent(splServiceMock, configServiceMock, currencyPipeMock, datePipeMock);
  });

  it('should create SplItemGridComponent', () => {
    expect(component).toBeTruthy();
  });

  describe('ngOnInit', () => {
    it('should test ngOnInit', () => {
      const getUserPreferencesSpy = jest.spyOn(splServiceMock, 'getUserPreferences').mockImplementationOnce(() => of(userGridPreferenceDtoMock));
      component.ngOnInit();
      expect(getUserPreferencesSpy).toHaveBeenCalled();
      splDetailsBasedOnSplNumberIsReadyMock.next();
      expect(component).toBeTruthy();
    });
  });

  describe('addItem', () => {
    it('should check if the item already exist in the grid', () => {
      jest.spyOn(window, 'alert').mockImplementation(() => of(EMPTY));
      component.searchItem = "0045";
      component.addItem();
      expect(window.alert).toHaveBeenCalled();
    });

    it('should check If the item not exist in the grid but present in database', () => {
      jest.spyOn(window, 'alert').mockImplementation(() => of(EMPTY));
      component.searchItem = "0047";
      component.addItem();
      expect(component.splService.splDto.splProductDtos.findIndex(x => x.currentProductDto.productCode == '0047')).toBeGreaterThan(-1);
    });

    it('should check if the item neither exist in the grid nor in database', () => {
      jest.spyOn(window, 'alert').mockImplementation(() => of(EMPTY));
      component.searchItem = "12345";
      component.addItem();
      expect(window.alert).toHaveBeenCalled();
    });
  });

  describe('cloneObj', () => {
    it('should test cloneObj', () => {
      component.cloneObj(splGridColumnDtosMock[0]);
      expect(component).toBeTruthy();
    });
  });

  describe('onFilter', () => {
    it('should filter values', () => {
      const productCode = "0045";
      component.onFilter(productCode);
      expect(component.filteredItems.some(p => p.label === productCode)).toBeTruthy();
    });
  });

  describe('onSelect', () => {
    it('should set filteredItems as empty', () => {
      component.onSelect("0045");
      expect(component.filteredItems.length == 0).toBeTruthy();
    });
  });

  describe('onSortChange', () => {
    it('should test onSortChange for Item# as ascending', () => {
      const event: IUITKColumnState = { direction: 1, column: "Item#", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Item# as descending', () => {
      const event: IUITKColumnState = { direction: -1, column: "Item#", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Item Description as ascending', () => {
      const event: IUITKColumnState = { direction: 1, column: "Item Description", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Item Description as descending', () => {
      const event: IUITKColumnState = { direction: -1, column: "Item Description", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Max Disc. Allowed as ascending', () => {
      const event: IUITKColumnState = { direction: 1, column: "Max Disc. Allowed", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Max Disc. Allowed as descending', () => {
      const event: IUITKColumnState = { direction: -1, column: "Max Disc. Allowed", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for List Price as ascending', () => {
      const event: IUITKColumnState = { direction: 1, column: "List Price", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for List Price as descending', () => {
      const event: IUITKColumnState = { direction: -1, column: "List Price", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Floor Price as ascending', () => {
      const event: IUITKColumnState = { direction: 1, column: "Floor Price", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Floor Price as descending', () => {
      const event: IUITKColumnState = { direction: -1, column: "Floor Price", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for SPL Price as ascending', () => {
      const event: IUITKColumnState = { direction: 1, column: "SPL Price", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for SPL Price as descending', () => {
      const event: IUITKColumnState = { direction: -1, column: "SPL Price", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Disc % as ascending', () => {
      const event: IUITKColumnState = { direction: 1, column: "Disc %", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Disc % as descending', () => {
      const event: IUITKColumnState = { direction: -1, column: "Disc %", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Qty as ascending', () => {
      const event: IUITKColumnState = { direction: 1, column: "Qty", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Qty as descending', () => {
      const event: IUITKColumnState = { direction: -1, column: "Qty", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Effective Date as ascending', () => {
      const event: IUITKColumnState = { direction: 1, column: "Effective Date", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Effective Date as descending', () => {
      const event: IUITKColumnState = { direction: -1, column: "Effective Date", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Applied Disc at Cat Level as ascending', () => {
      const event: IUITKColumnState = { direction: 1, column: "Applied Disc at Cat Level", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Applied Disc at Cat Level as descending', () => {
      const event: IUITKColumnState = { direction: -1, column: "Applied Disc at Cat Level", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Curr Ed or CY Qty as ascending', () => {
      const event: IUITKColumnState = { direction: 1, column: "Curr Ed or CY Qty", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Curr Ed or CY Qty as descending', () => {
      const event: IUITKColumnState = { direction: -1, column: "Curr Ed or CY Qty", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Curr Ed or CY Qty as ascending', () => {
      const event: IUITKColumnState = { direction: 1, column: "Curr Ed or CY Qty", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Curr Ed or CY Qty as descending', () => {
      const event: IUITKColumnState = { direction: -1, column: "Curr Ed or CY Qty", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Edition Yr as ascending', () => {
      const event: IUITKColumnState = { direction: 1, column: "Edition Yr", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Edition Yr as descending', () => {
      const event: IUITKColumnState = { direction: -1, column: "Edition Yr", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Prev Ed or PY Avg Disc. % as ascending', () => {
      const event: IUITKColumnState = { direction: 1, column: "Prev Ed or PY Avg Disc. %", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Prev Ed or PY Avg Disc. % as descending', () => {
      const event: IUITKColumnState = { direction: -1, column: "Prev Ed or PY Avg Disc. %", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Prev Ed or PY Qty as ascending', () => {
      const event: IUITKColumnState = { direction: 1, column: "Prev Ed or PY Qty", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Prev Ed or PY Qty as descending', () => {
      const event: IUITKColumnState = { direction: -1, column: "Prev Ed or PY Qty", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Price List Cat as ascending', () => {
      const event: IUITKColumnState = { direction: 1, column: "Price List Cat", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Price List Cat as descending', () => {
      const event: IUITKColumnState = { direction: -1, column: "Price List Cat", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Price List Cat Yr as ascending', () => {
      const event: IUITKColumnState = { direction: 1, column: "Price List Cat Yr", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Price List Cat Yr as descending', () => {
      const event: IUITKColumnState = { direction: -1, column: "Price List Cat Yr", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for PY SPL Disc % as ascending', () => {
      const event: IUITKColumnState = { direction: 1, column: "PY SPL Disc %", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for PY SPL Disc % as descending', () => {
      const event: IUITKColumnState = { direction: -1, column: "PY SPL Disc %", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for PY SPL Price as ascending', () => {
      const event: IUITKColumnState = { direction: 1, column: "PY SPL Price", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for PY SPL Price as descending', () => {
      const event: IUITKColumnState = { direction: -1, column: "PY SPL Price", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Total Sales Based on SPL Price as ascending', () => {
      const event: IUITKColumnState = { direction: 1, column: "Total Sales Based on SPL Price", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Total Sales Based on SPL Price as descending', () => {
      const event: IUITKColumnState = { direction: -1, column: "Total Sales Based on SPL Price", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Total Sales Based on Target Price as ascending', () => {
      const event: IUITKColumnState = { direction: 1, column: "Total Sales Based on Target Price", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Total Sales Based on Target Price as descending', () => {
      const event: IUITKColumnState = { direction: -1, column: "Total Sales Based on Target Price", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Target Price as ascending', () => {
      const event: IUITKColumnState = { direction: 1, column: "Target Price", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });

    it('should test onSortChange for Target Price as descending', () => {
      const event: IUITKColumnState = { direction: -1, column: "Target Price", enabled: true };
      component.splProducts = splProductDtosMock;
      component.onSortChange(event);
      expect(component).toBeTruthy();
    });
  });

  describe('applyFields', () => {
    it('should test applyFields', () => {
      component.allColumns = splGridColumnDtosMock;
      component.selectedColumns = splGridColumnDtosMock;
      component.applyFields();
      expect(component).toBeTruthy();
    });
  });

  describe('saveUserPreferences', () => {
    it('should test applyFields', () => {
      component.allColumns = splGridColumnDtosMock;
      component.selectedColumns = splGridColumnDtosMock;
      jest.spyOn(window, 'alert').mockImplementation(() => of(EMPTY));
      component.saveUserPreferences();
      expect(window.alert).toBeCalledWith('User Preferences saved successfully');
      expect(component).toBeTruthy();
    });
  });

  describe('restoreToDefaults', () => {
    it('should test restoreToDefaults', () => {
      component.allColumns = splGridColumnDtosMock;
      component.defaultSelectedColumns = splGridColumnDtosMock;
      component.selectedColumns = splGridColumnDtosMock;
      jest.spyOn(window, 'alert').mockImplementation(() => of(EMPTY));
      const getUserPreferencesSpy = jest.spyOn(splServiceMock, 'getUserPreferences').mockImplementationOnce(() => of(userGridPreferenceDtoMock));
      component.restoreToDefaults();
      expect(getUserPreferencesSpy).toHaveBeenCalled();
      expect(window.alert).toBeCalledWith('User Preferences saved successfully');
      expect(component).toBeTruthy();
    });
  });

  describe('overallDiscountReduction', () => {
    it('should test overallDiscountReduction', () => {
      component.discountReduction = 5;
      component.overallDiscountReduction();
      expect(component).toBeTruthy();
    });
  });

  describe('getColumnData', () => {
    it('should test getColumnData for Item# column', () => {
      component.getColumnData('Item#', splProductDtosMock[0]);
      expect(component).toBeTruthy();
    });

    it('should test getColumnData for Item Description column', () => {
      component.getColumnData('Item Description', splProductDtosMock[0]);
      expect(component).toBeTruthy();
    });

    it('should test getColumnData for Max Disc. Allowed column', () => {
      component.getColumnData('Max Disc. Allowed', splProductDtosMock[0]);
      expect(component).toBeTruthy();
    });

    it('should test getColumnData for List Price column', () => {
      component.getColumnData('List Price', splProductDtosMock[0]);
      expect(component).toBeTruthy();
    });

    it('should test getColumnData for Floor Price column', () => {
      component.getColumnData('Floor Price', splProductDtosMock[0]);
      expect(component).toBeTruthy();
    });

    it('should test getColumnData for SPL Price column', () => {
      component.getColumnData('SPL Price', splProductDtosMock[0]);
      expect(component).toBeTruthy();
    });

    it('should test getColumnData for Disc % column', () => {
      component.getColumnData('Disc %', splProductDtosMock[0]);
      expect(component).toBeTruthy();
    });

    it('should test getColumnData for Qty column', () => {
      component.getColumnData('Qty', splProductDtosMock[0]);
      expect(component).toBeTruthy();
    });

    it('should test getColumnData for Effective Date column', () => {
      component.getColumnData('Effective Date', splProductDtosMock[0]);
      expect(component).toBeTruthy();
    });

    it('should test getColumnData for Applied Disc at Cat Level column', () => {
      component.getColumnData('Applied Disc at Cat Level', splProductDtosMock[0]);
      expect(component).toBeTruthy();
    });

    it('should test getColumnData for Curr Ed or CY Qty column', () => {
      component.getColumnData('Curr Ed or CY Qty', splProductDtosMock[0]);
      expect(component).toBeTruthy();
    });

    it('should test getColumnData for Edition Yr column', () => {
      component.getColumnData('Edition Yr', splProductDtosMock[0]);
      expect(component).toBeTruthy();
    });

    it('should test getColumnData for Prev Ed or PY Avg Disc. % column', () => {
      component.getColumnData('Prev Ed or PY Avg Disc. %', splProductDtosMock[0]);
      expect(component).toBeTruthy();
    });

    it('should test getColumnData for Prev Ed or PY Qty column', () => {
      component.getColumnData('Prev Ed or PY Qty', splProductDtosMock[0]);
      expect(component).toBeTruthy();
    });

    it('should test getColumnData for Price List Cat column', () => {
      component.getColumnData('Price List Cat', splProductDtosMock[0]);
      expect(component).toBeTruthy();
    });

    it('should test getColumnData for Price List Cat Yr column', () => {
      component.getColumnData('Price List Cat Yr', splProductDtosMock[0]);
      expect(component).toBeTruthy();
    });

    it('should test getColumnData for PY SPL Disc % column', () => {
      component.getColumnData('PY SPL Disc %', splProductDtosMock[0]);
      expect(component).toBeTruthy();
    });

    it('should test getColumnData for PY SPL Price column', () => {
      component.getColumnData('PY SPL Price', splProductDtosMock[0]);
      expect(component).toBeTruthy();
    });

    it('should test getColumnData for Total Sales Based on SPL Price column', () => {
      component.getColumnData('Total Sales Based on SPL Price', splProductDtosMock[0]);
      expect(component).toBeTruthy();
    });

    it('should test getColumnData for Total Sales Based on Target Price column', () => {
      component.getColumnData('Total Sales Based on Target Price', splProductDtosMock[0]);
      expect(component).toBeTruthy();
    });

    it('should test getColumnData for Target Price column', () => {
      component.getColumnData('Target Price', splProductDtosMock[0]);
      expect(component).toBeTruthy();
    });
  });

  describe('ngOnDestroy', () => {
    it('should test ngOnDestroy', () => {
      component['splDetailsBasedOnSplNumberIsReadySubscription'] = of().subscribe();
      component.ngOnDestroy();
      expect(component).toBeTruthy();
    });
  });
});
