import { CurrencyPipe, DatePipe } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { IUITKColumnState, IUITKSelectItemProps, UITKInputDirective } from '@uitk/angular';
import { Subscription } from 'rxjs';
import { Column } from '../../../models/column-dto.model';
import { ProductDto } from '../../../models/product-dto.model';
import { SplDto } from '../../../models/spl-dto.model';
import { SplGridColumnDto } from '../../../models/spl-item-grid-column-dto.model';
import { SplProductDto } from '../../../models/spl-product-dto.model';
import { UserGridPreferenceDto } from '../../../models/user-grid-preference-dto.model';
import { ConfigService } from '../../../services/config.service';
import { SplService } from '../../../services/spl.service';

@Component({
  selector: 'app-spl-item-grid',
  templateUrl: './spl-item-grid.component.html',
  styleUrls: ['./spl-item-grid.component.scss']
})

export class SplItemGridComponent implements OnInit, OnDestroy {
  private splDetailsBasedOnSplNumberIsReadySubscription!: Subscription;
  discountReduction = 0;
  items: ProductDto[] = [];
  itemsLabel: { id: number, label: string }[] = [];
  input: UITKInputDirective | undefined;
  charTriggerLength = 2;
  gridName = 'SplProductGrid';
  userName = '';
  filteredItems: { id: number, label: string }[] = [];
  openFieldMenu = false;
  autocompleteForm = new FormGroup({
    autoComplete: new FormControl(),
  });
  tableHeader = [
    {
      name: 'Max Disc. Allowed', id: 'MaxDiscAllowed'
    },
    {
      name: 'List Price', id: 'ListPrice'
    },
    {
      name: 'Floor Price', id: 'FloorPrice'
    },
    {
      name: 'SPL Price', id: 'SplPrice'
    },
    {
      name: 'Disc. %', id: 'Discount'
    },
    {
      name: 'Qty', id: 'Quantity'
    },
    {
      name: 'Effective Date', id: 'EffectiveDate'
    }
  ];
  priceListCategories: IUITKSelectItemProps[] = [];
  selectedPriceListCategory!: IUITKSelectItemProps;
  splProducts: SplProductDto[] = [];
  searchItem = '';

  allColumns: SplGridColumnDto[] = [
    { columnId: 1, name: 'ItemNumber', title: 'Item#', frozen: false, isShown: true, isFieldDisabled: true, fieldType: 'span', format: '', position: 0 },//product.currentProductDto.productCode
    { columnId: 2, name: 'ItemDescription', title: 'Item Description', frozen: false, isShown: false, isFieldDisabled: false, fieldType: 'span', format: '', position: 0 },//product.currentProductDto.description
    { columnId: 3, name: 'MaxDiscAllowed', title: 'Max Disc. Allowed', frozen: false, isShown: false, isFieldDisabled: false, fieldType: 'span', format: '', position: 0 },//product.currentProductDto.maxDiscountPercent
    { columnId: 4, name: 'ListPrice', title: 'List Price', frozen: false, isShown: false, isFieldDisabled: false, fieldType: 'span', format: '', position: 0 },//product.currentPriceCatalogDto?.listPrice
    { columnId: 5, name: 'FloorPrice', title: 'Floor Price', frozen: false, isShown: false, isFieldDisabled: false, fieldType: 'span', format: '', position: 0 },//product.currentPriceCatalogDto?.floorPrice
    { columnId: 6, name: 'SplPrice', title: 'SPL Price', frozen: false, isShown: true, isFieldDisabled: true, fieldType: 'text', format: 'price', position: 0 },//product.splPrice
    { columnId: 7, name: 'Discount', title: 'Disc %', frozen: false, isShown: true, isFieldDisabled: true, fieldType: 'text', format: 'discount', position: 0 },//product.splDiscount
    { columnId: 8, name: 'Quantity', title: 'Qty', frozen: false, isShown: false, isFieldDisabled: false, fieldType: 'text', format: 'quantity', position: 0 },//product.quantity
    { columnId: 9, name: 'EffectiveDate', title: 'Effective Date', frozen: false, isShown: false, isFieldDisabled: false, fieldType: 'span', format: '', position: 0 },//product.effectiveDate
    { columnId: 10, name: 'AppliedDiscountCat', title: 'Applied Disc at Cat Level', frozen: false, isShown: false, isFieldDisabled: false, fieldType: 'span', format: '', position: 0 },//product.appliedCategoryDiscount
    { columnId: 11, name: 'CurrEdOrCYQty', title: 'Curr Ed or CY Qty', frozen: false, isShown: false, isFieldDisabled: false, fieldType: 'span', format: '', position: 0 },//product.currentOrderSummaryDto.unitsold
    { columnId: 12, name: 'EditionYear', title: 'Edition Yr', frozen: false, isShown: false, isFieldDisabled: false, fieldType: 'span', format: '', position: 0 },//product.currentProductDto.editionYear
    { columnId: 13, name: 'PrevEdOrPYAvgDiscount', title: 'Prev Ed or PY Avg Disc. %', frozen: false, isShown: false, isFieldDisabled: false, fieldType: 'span', format: '', position: 0 },//product.priorOrderSummaryDto.AverageDiscount
    { columnId: 14, name: 'PrevEdQty', title: 'Prev Ed or PY Qty', frozen: false, isShown: false, isFieldDisabled: false, fieldType: 'span', format: '', position: 0 },//product.priorOrderSummaryDto.unitsold
    { columnId: 15, name: 'PriceListCat', title: 'Price List Cat', frozen: false, isShown: false, isFieldDisabled: false, fieldType: 'span', format: '', position: 0 },//product.currentProductDto.priceListCategory
    { columnId: 16, name: 'PriceListCatYear', title: 'Price List Cat Yr', frozen: false, isShown: false, isFieldDisabled: false, fieldType: 'span', format: '', position: 0 },//product.currentProductDto.priceListCategoryYear
    { columnId: 17, name: 'PYSplDiscount', title: 'PY SPL Disc %', frozen: false, isShown: false, isFieldDisabled: false, fieldType: 'span', format: '', position: 0 },//product.PriorSplDiscount
    { columnId: 18, name: 'PYSplPrice', title: 'PY SPL Price', frozen: false, isShown: false, isFieldDisabled: false, fieldType: 'span', format: '', position: 0 },//product.PriorSplPrice
    { columnId: 19, name: 'TotalSalesOnSplPrice', title: 'Total Sales Based on SPL Price', frozen: false, isShown: false, isFieldDisabled: false, fieldType: 'span', format: '', position: 0 },//product.quantity * product.splPrice
    { columnId: 20, name: 'TotalSalesOnTargetPrice', title: 'Total Sales Based on Target Price', frozen: false, isShown: false, isFieldDisabled: false, fieldType: 'span', format: '', position: 0 },//product.quantity * product.CurrentPriceCatalogDto.TargetPrice
    { columnId: 21, name: 'TargetPrice', title: 'Target Price', frozen: false, isShown: false, isFieldDisabled: false, fieldType: 'span', format: '', position: 0 }//product.CurrentPriceCatalogDto.TargetPrice
  ];

  selectedColumns: SplGridColumnDto[] = [];
  defaultSelectedColumns: SplGridColumnDto[] = [];
  userGridPreferenceDto!: UserGridPreferenceDto;

  constructor(
    public splService: SplService,
    private configService: ConfigService,
    private currencyPipe: CurrencyPipe,
    private datePipe: DatePipe) {
  }

  ngOnInit(): void {
    this.userName = this.configService.getMyMSId();
    this.getUserPreferences();


    this.configService.categoryDtos.forEach(element => {
      this.priceListCategories.push({ id: element.id.toString(), label: element.categoryNumber + ' - ' + element.categoryDescription, value: element.categoryNumber + ' - ' + element.categoryDescription });
    });

    this.splDetailsBasedOnSplNumberIsReadySubscription = this.splService.splDetailsBasedOnSplNumberIsReady.subscribe((data: SplDto) => {
      this.splProducts = data.splProductDtos;
    });
  }
  getUserPreferences(): void {
    this.splService.getUserPreferences(this.userName, this.gridName).subscribe((data: UserGridPreferenceDto) => {
      this.userGridPreferenceDto = data;

      this.allColumns.forEach(element => {
        const index = this.userGridPreferenceDto.columns.findIndex(u => u.columnName === element.name);
        element.position = index > -1 ? this.userGridPreferenceDto.columns[index].position : this.allColumns.length;
        element.isShown = index > -1 ? true : false;
      });

      this.allColumns = this.allColumns.sort((a, b) => 0 - (a.position > b.position ? -1 : 1));
      this.allColumns[0].frozen = true;
      this.allColumns[1].frozen = true;
      this.allColumns = [...this.allColumns];
      this.selectedColumns = [];
      this.allColumns.forEach(item => {
        this.selectedColumns.push(this.cloneObj(item));
        this.defaultSelectedColumns.push(this.cloneObj(item));
      });
    });
  }
  cloneObj(fieldItem: SplGridColumnDto): SplGridColumnDto {
    const obj = new SplGridColumnDto();
    obj.columnId = fieldItem.columnId;
    obj.name = fieldItem.name;
    obj.title = fieldItem.title;
    obj.frozen = fieldItem.frozen;
    obj.isShown = fieldItem.isShown;
    obj.isFieldDisabled = fieldItem.isFieldDisabled;
    obj.fieldType = fieldItem.fieldType;
    obj.format = fieldItem.format;
    obj.position = fieldItem.position;
    return obj;
  }

  onFilter(value: string): void {
    this.items = this.configService.productDtos.sort((a, b) => a.productCode > b.productCode ? 1 : -1);
    this.itemsLabel = [...new Set(this.items.map(item => ({ id: item.currentProductId, label: item.productCode })))];
    this.filteredItems = this.itemsLabel.filter((element) => element.label.trim().startsWith(value));
    console.log("filteredItems", this.filteredItems);
  }

  onSelect(value: string): void {
    console.log('selected option: ', value);
    this.filteredItems = [];
  }

  addItem(): void {
    if (this.splService.splDto.splProductDtos.findIndex(sp => sp.currentProductDto.productCode === this.searchItem) > -1) {
      alert(`The Item ${this.searchItem} already exists`);
    }
    else if (this.configService.productDtos.filter(p => p.productCode === this.searchItem).length > 0) {
      const currentProductDto = this.configService.productDtos.filter(element => element.productCode === this.searchItem)[0];
      const priorProductDto = this.configService.productDtos.filter(element => element.currentProductId === currentProductDto.priorProductId)[0];
      const splProductDto: SplProductDto = new SplProductDto();
      splProductDto.productId = currentProductDto.currentProductId;
      splProductDto.splDiscount = 0;
      splProductDto.splPrice = 0; 
      splProductDto.quantity = 0;
      splProductDto.currentProductDto = currentProductDto;
      splProductDto.priorProductDto = priorProductDto;
      this.splService.splDto.splProductDtos.push(splProductDto);

      this.splService.splDto.splProductDtos = [...this.splService.splDto.splProductDtos];
      this.splService.splDetailsBasedOnSplNumberIsReady.next(this.splService.splDto);
    }
    else if (this.configService.productDtos.filter(element => element.productCode === this.searchItem).length === 0) {
      alert("This is not a valid Item #");
    }

    this.searchItem = '';
  }

  onSortChange(event: IUITKColumnState): void {
    switch (event.column) {
      case 'Item#':
        switch (event.direction) {
          case 1:
            this.splProducts.sort((a, b) => 0 - (a.currentProductDto.productCode > b.currentProductDto.productCode ? -1 : 1));
            break;
          case -1:
            this.splProducts.sort((a, b) => 0 - (a.currentProductDto.productCode > b.currentProductDto.productCode ? 1 : -1));
            break;
        }

        break;
      case 'Item Description':
        switch (event.direction) {
          case 1:
            this.splProducts.sort((a, b) => 0 - (a.currentProductDto.description > b.currentProductDto.description ? -1 : 1));
            break;
          case -1:
            this.splProducts.sort((a, b) => 0 - (a.currentProductDto.description > b.currentProductDto.description ? 1 : -1));
            break;
        }

        break;
      case 'Max Disc. Allowed':
        switch (event.direction) {
          case 1:
            this.splProducts.sort((a, b) => 0 - (a.currentProductDto.maxDiscountPercent > b.currentProductDto.maxDiscountPercent ? -1 : 1));
            break;
          case -1:
            this.splProducts.sort((a, b) => 0 - (a.currentProductDto.maxDiscountPercent > b.currentProductDto.maxDiscountPercent ? 1 : -1));
            break;
        }

        break;
      case 'List Price':
        switch (event.direction) {
          case 1:
            this.splProducts.sort((a, b) => 0 - ((a.currentProductDto.priceCatalogDto?.listPrice ?? 0) > (b.currentProductDto.priceCatalogDto?.listPrice ?? 0) ? -1 : 1));
            break;
          case -1:
            this.splProducts.sort((a, b) => 0 - ((a.currentProductDto.priceCatalogDto?.listPrice ?? 0) > (b.currentProductDto.priceCatalogDto?.listPrice ?? 0) ? 1 : -1));
            break;
        }

        break;
      case 'Floor Price':
        switch (event.direction) {
          case 1:
            this.splProducts.sort((a, b) => 0 - ((a.currentProductDto.priceCatalogDto?.floorPrice ?? 0) > (b.currentProductDto.priceCatalogDto?.floorPrice ?? 0) ? -1 : 1));
            break;
          case -1:
            this.splProducts.sort((a, b) => 0 - ((a.currentProductDto.priceCatalogDto?.floorPrice ?? 0) > (b.currentProductDto.priceCatalogDto?.floorPrice ?? 0) ? 1 : -1));
            break;
        }

        break;
      case 'SPL Price':
        switch (event.direction) {
          case 1:
            this.splProducts.sort((a, b) => 0 - (a.splPrice > b.splPrice ? -1 : 1));
            break;
          case -1:
            this.splProducts.sort((a, b) => 0 - (a.splPrice > b.splPrice ? 1 : -1));
            break;
        }

        break;
      case 'Disc %':
        switch (event.direction) {
          case 1:
            this.splProducts.sort((a, b) => 0 - (a.splDiscount > b.splDiscount ? -1 : 1));
            break;
          case -1:
            this.splProducts.sort((a, b) => 0 - (a.splDiscount > b.splDiscount ? 1 : -1));
            break;
        }

        break;
      case 'Qty':
        switch (event.direction) {
          case 1:
            this.splProducts.sort((a, b) => 0 - (a.quantity > b.quantity ? -1 : 1));
            break;
          case -1:
            this.splProducts.sort((a, b) => 0 - (a.quantity > b.quantity ? 1 : -1));
            break;
        }

        break;
      case 'Effective Date':
        switch (event.direction) {
          case 1:
            this.splProducts.sort((a, b) => 0 - (a.effectiveDate > b.effectiveDate ? -1 : 1));
            break;
          case -1:
            this.splProducts.sort((a, b) => 0 - (a.effectiveDate > b.effectiveDate ? 1 : -1));
            break;
        }

        break;
      case 'Applied Disc at Cat Level':
        switch (event.direction) {
          case 1:
            this.splProducts.sort((a, b) => 0 - (a.appliedCategoryDiscount > b.appliedCategoryDiscount ? -1 : 1));
            break;
          case -1:
            this.splProducts.sort((a, b) => 0 - (a.appliedCategoryDiscount > b.appliedCategoryDiscount ? 1 : -1));
            break;
        }

        break;
      case 'Curr Ed or CY Qty':
        switch (event.direction) {
          case 1:
            this.splProducts.sort((a, b) => 0 - ((a.currentProductDto.orderSummaryDto?.unitsSold ?? 0) > (b.currentProductDto.orderSummaryDto?.unitsSold ?? 0) ? -1 : 1));
            break;
          case -1:
            this.splProducts.sort((a, b) => 0 - ((a.currentProductDto.orderSummaryDto?.unitsSold ?? 0) > (b.currentProductDto.orderSummaryDto?.unitsSold ?? 0) ? 1 : -1));
            break;
        }

        break;
      case 'Edition Yr':
        switch (event.direction) {
          case 1:
            this.splProducts.sort((a, b) => 0 - ((a.currentProductDto.editionYear ?? 0) > (b.currentProductDto.editionYear ?? 0) ? -1 : 1));
            break;
          case -1:
            this.splProducts.sort((a, b) => 0 - ((a.currentProductDto.editionYear ?? 0) > (b.currentProductDto.editionYear ?? 0) ? 1 : -1));
            break;
        }

        break;
      case 'Prev Ed or PY Avg Disc. %':
        switch (event.direction) {
          case 1:
            this.splProducts.sort((a, b) => 0 - ((a.priorProductDto?.orderSummaryDto?.averageDiscount ?? 0) > (b.priorProductDto?.orderSummaryDto?.averageDiscount ?? 0) ? -1 : 1));
            break;
          case -1:
            this.splProducts.sort((a, b) => 0 - ((a.priorProductDto?.orderSummaryDto?.averageDiscount ?? 0) > (b.priorProductDto?.orderSummaryDto?.averageDiscount ?? 0) ? 1 : -1));
            break;
        }

        break;
      case 'Prev Ed or PY Qty':
        switch (event.direction) {
          case 1:
            this.splProducts.sort((a, b) => 0 - ((a.priorProductDto?.orderSummaryDto?.unitsSold ?? 0) > (b.priorProductDto?.orderSummaryDto?.unitsSold ?? 0) ? -1 : 1));
            break;
          case -1:
            this.splProducts.sort((a, b) => 0 - ((a.priorProductDto?.orderSummaryDto?.unitsSold ?? 0) > (b.priorProductDto?.orderSummaryDto?.unitsSold ?? 0) ? 1 : -1));
            break;
        }

        break;
      case 'Price List Cat':
        switch (event.direction) {
          case 1:
            this.splProducts.sort((a, b) => 0 - (a.currentProductDto.priceListCategory > b.currentProductDto.priceListCategory ? -1 : 1));
            break;
          case -1:
            this.splProducts.sort((a, b) => 0 - (a.currentProductDto.priceListCategory > b.currentProductDto.priceListCategory ? 1 : -1));
            break;
        }

        break;
      case 'Price List Cat Yr':
        switch (event.direction) {
          case 1:
            this.splProducts.sort((a, b) => 0 - ((a.currentProductDto.priceListCategoryYear ?? 0) > (b.currentProductDto.priceListCategoryYear ?? 0) ? -1 : 1));
            break;
          case -1:
            this.splProducts.sort((a, b) => 0 - ((a.currentProductDto.priceListCategoryYear ?? 0) > (b.currentProductDto.priceListCategoryYear ?? 0) ? 1 : -1));
            break;
        }

        break;
      case 'PY SPL Disc %':
        switch (event.direction) {
          case 1:
            this.splProducts.sort((a, b) => 0 - (a.priorSplDiscount > b.priorSplDiscount ? -1 : 1));
            break;
          case -1:
            this.splProducts.sort((a, b) => 0 - (a.priorSplDiscount > b.priorSplDiscount ? 1 : -1));
            break;
        }

        break;
      case 'PY SPL Price':
        switch (event.direction) {
          case 1:
            this.splProducts.sort((a, b) => 0 - (a.priorSplPrice > b.priorSplPrice ? -1 : 1));
            break;
          case -1:
            this.splProducts.sort((a, b) => 0 - (a.priorSplPrice > b.priorSplPrice ? 1 : -1));
            break;
        }

        break;
      case 'Total Sales Based on SPL Price':
        switch (event.direction) {
          case 1:
            this.splProducts.sort((a, b) => 0 - (a.quantity * a.splPrice > b.quantity * b.splPrice ? -1 : 1));
            break;
          case -1:
            this.splProducts.sort((a, b) => 0 - (a.quantity * a.splPrice > b.quantity * b.splPrice ? 1 : -1));
            break;
        }

        break;
      case 'Total Sales Based on Target Price':
        switch (event.direction) {
          case 1:
            this.splProducts.sort((a, b) => 0 - ((a.quantity * (a.currentProductDto?.priceCatalogDto?.targetPrice ?? 0)) > (b.quantity * (b.currentProductDto?.priceCatalogDto?.targetPrice ?? 0)) ? -1 : 1));
            break;
          case -1:
            this.splProducts.sort((a, b) => 0 - ((a.quantity * (a.currentProductDto?.priceCatalogDto?.targetPrice ?? 0)) > (b.quantity * (b.currentProductDto?.priceCatalogDto?.targetPrice ?? 0)) ? 1 : -1));
            break;
        }

        break;
      case 'Target Price':
        switch (event.direction) {
          case 1:
            this.splProducts.sort((a, b) => 0 - (a.currentProductDto?.priceCatalogDto?.targetPrice ?? 0) > (b.currentProductDto?.priceCatalogDto?.targetPrice ?? 0) ? -1 : 1);
            break;
          case -1:
            this.splProducts.sort((a, b) => 0 - (a.currentProductDto?.priceCatalogDto?.targetPrice ?? 0) > (b.currentProductDto?.priceCatalogDto?.targetPrice ?? 0) ? 1 : -1);
            break;
        }

        break;
    }

    this.splProducts = [...this.splProducts];
  }

  applyFields(): void {
    this.openFieldMenu = false;

    this.selectedColumns.forEach(item => {
      const index = this.allColumns.findIndex(x => x.columnId == item.columnId);
      this.allColumns[index].isShown = item.isShown;
    });

    const shownColumns: SplGridColumnDto[] = this.allColumns.filter(ac => ac.isShown);

    shownColumns.forEach((element, value) => {
      const index = this.allColumns.findIndex(ac => ac.title === element.title);
      this.allColumns[index].position = index > -1 ? (value + 1) : this.allColumns.length;
    });

    this.selectedColumns = [];

    this.allColumns.forEach(item => {
      this.selectedColumns.push(this.cloneObj(item));
    });

    this.allColumns = this.allColumns.sort((a, b) => 0 - (a.position > b.position ? -1 : 1));
    this.allColumns = [...this.allColumns];

  }

  saveUserPreferences(): void {
    this.applyFields();

    const shownColumns: SplGridColumnDto[] = this.allColumns.filter(ac => ac.isShown);
    this.userGridPreferenceDto = new UserGridPreferenceDto();
    this.userGridPreferenceDto.userLogin = this.userName;
    this.userGridPreferenceDto.gridName = this.gridName
    this.userGridPreferenceDto.columns = [];

    shownColumns.forEach((element) => {
      const column = new Column();
      column.columnName = element.name;
      column.position = element.position;
      this.userGridPreferenceDto.columns.push(column);
    });

    this.splService.saveUserPreferences(this.userGridPreferenceDto).subscribe(() => {
      alert('User Preferences saved successfully');
    },
      error => {
        alert('Error updating User Preferences' + error.Message);
      });
  }

  restoreToDefaults(): void {
    this.openFieldMenu = false;
    this.userGridPreferenceDto = new UserGridPreferenceDto();
    this.userGridPreferenceDto.userLogin = this.userName;
    this.userGridPreferenceDto.gridName = this.gridName
    this.userGridPreferenceDto.columns = [];
    this.splService.saveUserPreferences(this.userGridPreferenceDto).subscribe(() => {
      alert('User Preferences saved successfully');
      this.getUserPreferences();
    },
      error => {
        alert('Error updating User Preferences' + error.Message);
      });
  }

  overallDiscountReduction(): void {
    this.splService.splDto.splProductDtos.forEach(item => {
      item.splDiscount = item.splDiscount - this.discountReduction;
      item.splDiscount = item.splDiscount > 0 ? item.splDiscount : 0;
      this.splService.calculateSplPrice(item);//updating splPrice upon discount change
    });

    this.splService.splDto.belowFloorPrice = this.splService.calculateItemsBelowFP();
    this.splService.splDto.splProductDtos = [...this.splService.splDto.splProductDtos];
    this.splService.splDetailsBasedOnSplNumberIsReady.next(this.splService.splDto);
  }

  getColumnData(columnTitle: string, product: SplProductDto): unknown {
    let returnData: unknown = null;

    switch (columnTitle) {
      case 'Item#':
        returnData = product.currentProductDto.productCode;
        break;
      case 'Item Description':
        returnData = product.currentProductDto.description;
        break;
      case 'Max Disc. Allowed':
        returnData = product.currentProductDto.maxDiscountPercent;
        break;
      case 'List Price':
        returnData = !product.currentProductDto?.priceCatalogDto ? this.currencyPipe.transform(0, 'USD', 'symbol-narrow') : this.currencyPipe.transform(product.currentProductDto.priceCatalogDto?.listPrice, 'USD', 'symbol-narrow');
        break;
      case 'Floor Price':
        returnData = !product.currentProductDto?.priceCatalogDto ? this.currencyPipe.transform(0, 'USD', 'symbol-narrow') : this.currencyPipe.transform(product.currentProductDto.priceCatalogDto?.floorPrice, 'USD', 'symbol-narrow');
        break;
      case 'SPL Price':
        returnData = product.splPrice;
        break;
      case 'Disc %':
        returnData = product.splDiscount;
        break;
      case 'Qty':
        returnData = product.quantity;
        break;
      case 'Effective Date':
        returnData = this.datePipe.transform(product.effectiveDate, 'MM/dd/yyyy');
        break;
      case 'Applied Disc at Cat Level':
        returnData = product.appliedCategoryDiscount;
        break;
      case 'Curr Ed or CY Qty':
        returnData = !product.currentProductDto?.orderSummaryDto ? 0 : product.currentProductDto?.orderSummaryDto?.unitsSold;
        break;
      case 'Edition Yr':
        returnData = product.currentProductDto.editionYear;
        break;
      case 'Prev Ed or PY Avg Disc. %':
        returnData = !product.priorProductDto?.orderSummaryDto ? 0 : product.priorProductDto?.orderSummaryDto?.averageDiscount;
        break;
      case 'Prev Ed or PY Qty':
        returnData = !product.priorProductDto?.orderSummaryDto ? 0 : product.priorProductDto?.orderSummaryDto?.unitsSold;
        break;
      case 'Price List Cat':
        returnData = product.currentProductDto.priceListCategory;
        break;
      case 'Price List Cat Yr':
        returnData = product.currentProductDto.priceListCategoryYear;
        break;
      case 'PY SPL Disc %':
        returnData = product.priorSplDiscount;
        break;
      case 'PY SPL Price':
        returnData = product.priorSplPrice;
        break;
      case 'Total Sales Based on SPL Price':
        returnData = product.quantity * product.splPrice;
        break;
      case 'Total Sales Based on Target Price':
        returnData = !product.currentProductDto.priceCatalogDto ? 0 : product.quantity * product.currentProductDto.priceCatalogDto?.targetPrice;
        break;
      case 'Target Price':
        returnData = !product.currentProductDto.priceCatalogDto ? 0 : product.currentProductDto.priceCatalogDto.targetPrice;
        break;
    }

    return returnData;
  }

  onChangeSplPrice(product: SplProductDto): void {
    this.splService.calculateDiscount(product);
    this.splService.refreshFields();
  }

  onChangeDiscount(product: SplProductDto): void {
    this.splService.calculateSplPrice(product);
    this.splService.refreshFields();
  }

  onChangeQuantity(): void {
    this.splService.refreshFields();
  }

  ngOnDestroy(): void {
    this.splDetailsBasedOnSplNumberIsReadySubscription.unsubscribe();
  }
}
