import { Component, OnInit } from '@angular/core';
import { SplService } from '../../services/spl.service';

@Component({
  selector: 'app-spl-edit',
  templateUrl: './spl-edit.component.html',
  styleUrls: ['./spl-edit.component.scss']
})
export class SplEditComponent implements OnInit {

  constructor(private splService: SplService) { }

  ngOnInit(): void {
    // TODO: Get the SPL from the database using the SPL Number entered into the URL
  }
}
