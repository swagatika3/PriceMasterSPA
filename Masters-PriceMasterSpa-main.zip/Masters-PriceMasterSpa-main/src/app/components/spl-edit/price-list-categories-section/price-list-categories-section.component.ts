import { Component, OnDestroy, OnInit } from '@angular/core';
import { IUITKSelectItemProps } from '@uitk/angular';
import { Subscription } from 'rxjs';
import { ProductDto } from '../../../models/product-dto.model';
import { SplProductDto } from '../../../models/spl-product-dto.model';
import { SplService } from '../../../services/spl.service';
import { PriceListCategoriesDto } from '../../../models/price-list-categories-dto.model';
import { ConfigService } from '../../../services/config.service';
import { SplDto } from 'src/app/models/spl-dto.model';

@Component({
  selector: 'app-price-list-categories-section',
  templateUrl: './price-list-categories-section.component.html',
  styleUrls: ['./price-list-categories-section.component.scss']
})

export class PriceListCategoriesSectionComponent implements OnInit, OnDestroy {
  private splDetailsBasedOnSplNumberIsReadySubscription!: Subscription;
  priceListCategoriesPanelClass = 'uitk-l-grid-open';
  collapsePriceListCategoriesPanel = true;
  openPriceListCategoriesPanel = true;
  tblPriceListCategoriesHeader = [{
    id: 'thDelete',
    name: ''
  }, {
    id: 'thPriceListCategory',
    name: 'Price List Category'
  }, {
    id: 'thSpecifiedDiscount',
    name: 'Specified Discount'
  }, {
    id: 'thApply',
    name: ''
  }];
  priceListCategories: PriceListCategoriesDto[] = [];
  categoriesList: IUITKSelectItemProps[] = [];
  selectedCategory: IUITKSelectItemProps | undefined;
  overallDiscount = 0;
  isAllPriceListCategoriesSelected = false;

  constructor(
    private configService: ConfigService, 
    public splService: SplService) {
  }

  ngOnInit(): void {
    this.getPriceListCategories();
  }

  getPriceListCategories(): void {
    this.splDetailsBasedOnSplNumberIsReadySubscription = this.splService.splDetailsBasedOnSplNumberIsReady.subscribe(() => {
      this.priceListCategories = [];

      this.splService.splDto.splCategoryDtos.forEach(element => {
        this.priceListCategories.push({
          isNewPriceListCategory: false,
          priceListCategoryId: element.categoryId,
          priceListCategory: this.configService.categoryDtos.filter(c => c.id === element.categoryId)[0].categoryNumber + ' - ' + this.configService.categoryDtos.filter(c => c.id === element.categoryId)[0].categoryDescription,
          specifiedDiscount: element.appliedDiscount
        });
      });

      this.priceListCategories = [...this.priceListCategories];
      this.categoriesList = [];

      this.configService.categoryDtos.forEach((element) => {
        if (element.accountTypeCode !== 'C') {
          let disableItem = false;
          const index = this.priceListCategories.findIndex(p => p.priceListCategory === (element.categoryNumber + ' - ' + element.categoryDescription));

          if (index > -1) {
            disableItem = true;
          }

          this.categoriesList.push({
            id: element.id.toString(),
            label: element.categoryNumber + ' - ' + element.categoryDescription,
            value: element.categoryNumber + ' - ' + element.categoryDescription,
            disabled: disableItem
          });
        }
      });

      this.categoriesList = [...this.categoriesList];
      this.isAllPriceListCategoriesSelected = this.categoriesList.filter(c => c.disabled).length === this.categoriesList.length ? true : false;
    });
  }

  setPanelForPriceListCategories(): void {
    if (this.priceListCategoriesPanelClass === 'uitk-l-grid-open') {
      this.priceListCategoriesPanelClass = 'uitk-l-grid1-close';
    }
    else {
      this.priceListCategoriesPanelClass = 'uitk-l-grid-open';
    }
  }

  addNewCategory(): void {
    const priceListCategory: PriceListCategoriesDto = new PriceListCategoriesDto();
    priceListCategory.isNewPriceListCategory = true;
    this.priceListCategories.push(priceListCategory);
    this.priceListCategories = [...this.priceListCategories];
  }

  deletePriceListCategory(index: number, column: number): void {
    const categoryIndex = this.categoriesList.findIndex(c => c.label === this.priceListCategories[index + index + column].priceListCategory);

    if (categoryIndex > -1) {
      this.categoriesList[categoryIndex].disabled = false;
      this.categoriesList = [...this.categoriesList];
      const index = this.splService.splDto.splCategoryDtos.findIndex(c => c.categoryId === Number(this.categoriesList[categoryIndex].id));
      this.splService.splDto.splCategoryDtos.splice(index, 1);
      this.splService.splDto.splCategoryDtos = [...this.splService.splDto.splCategoryDtos];
      this.splService.splDto.splProductDtos = this.splService.splDto.splProductDtos.filter(sp => sp.currentProductDto.categoryId !== Number(this.categoriesList[categoryIndex].id));
      this.splService.splDto.splProductDtos = [...this.splService.splDto.splProductDtos];
    }

    this.priceListCategories.splice(index + index + column, 1);
    this.priceListCategories = [...this.priceListCategories];
    this.splService.splDetailsBasedOnSplNumberIsReady.next(this.splService.splDto);
    this.isAllPriceListCategoriesSelected = this.categoriesList.filter(c => c.disabled).length === this.categoriesList.length ? true : false;
  }

  onChangeCategory(item: IUITKSelectItemProps, index: number, column: number): void {
    this.categoriesList.filter(c => c.id === item.id)[0].disabled = true;
    this.categoriesList = [...this.categoriesList];
    this.priceListCategories[index + index + column].priceListCategory = item.label;
    this.priceListCategories[index + index + column].specifiedDiscount = 0;
    this.priceListCategories[index + index + column].isNewPriceListCategory = false;
    this.priceListCategories[index + index + column].priceListCategoryId = Number(item.id);
    this.priceListCategories = [...this.priceListCategories];
    this.splService.splDto.splCategoryDtos.push({ categoryId: Number(item.id), appliedDiscount: 0 });
    this.splService.splDto.splCategoryDtos = [...this.splService.splDto.splCategoryDtos];
    const productDtos: ProductDto[] = this.configService.productDtos.filter(p => p.categoryId === Number(item.id));

    productDtos.forEach(element => {
      const splProductDto: SplProductDto = new SplProductDto();
      splProductDto.productId = element.currentProductId;
      splProductDto.effectiveDate = new Date();
      splProductDto.quantity = 0;
      splProductDto.splPrice = element.priceCatalogDto?.listPrice ?? 0;
      splProductDto.currentProductDto = element;
      splProductDto.priorProductDto = this.configService.productDtos.filter(p => p.currentProductId == element.priorProductId)[0];
      this.splService.splDto.splProductDtos.push(splProductDto);
    });

    this.splService.splDto.splProductDtos = [...this.splService.splDto.splProductDtos];
    this.splService.splDetailsBasedOnSplNumberIsReady.next(this.splService.splDto);
    this.isAllPriceListCategoriesSelected = this.categoriesList.filter(c => c.disabled).length === this.categoriesList.length ? true : false;
  }

  categoryWiseApplyDiscount(item: PriceListCategoriesDto): void {
    this.splService.splDto.splCategoryDtos = this.splService.splDto.splCategoryDtos.map(sc => sc.categoryId === item.priceListCategoryId ? { ...sc, appliedDiscount: item.specifiedDiscount } : sc);
    this.splService.splDto.splCategoryDtos = [...this.splService.splDto.splCategoryDtos];
    this.splService.splDto.splProductDtos = this.splService.splDto.splProductDtos.map(sp => sp.currentProductDto.categoryId === item.priceListCategoryId ? { ...sp, splDiscount: item.specifiedDiscount > sp.currentProductDto.maxDiscountPercent ? sp.currentProductDto.maxDiscountPercent : item.specifiedDiscount } : sp);

    this.calculateAllSplPrices(this.splService.splDto);
    this.splService.splDto.splProductDtos = [...this.splService.splDto.splProductDtos];
    this.splService.splDetailsBasedOnSplNumberIsReady.next(this.splService.splDto);
  }

  overallApplyDiscount(): void {
    this.priceListCategories.forEach(priceListCategory => {
      this.splService.splDto.splCategoryDtos = this.splService.splDto.splCategoryDtos.map(sc => sc.categoryId === priceListCategory.priceListCategoryId ? { ...sc, appliedDiscount: this.overallDiscount } : sc);
    });

    this.splService.splDto.splProductDtos.forEach(item => {
      item.splDiscount = this.overallDiscount > item.currentProductDto.maxDiscountPercent ? item.currentProductDto.maxDiscountPercent : this.overallDiscount;
    });
    this.calculateAllSplPrices(this.splService.splDto);
    this.splService.splDto.splCategoryDtos = [...this.splService.splDto.splCategoryDtos];
    this.splService.splDto.splProductDtos = [...this.splService.splDto.splProductDtos];
    this.splService.splDetailsBasedOnSplNumberIsReady.next(this.splService.splDto);
  }

  applyAllDiscount(): void {
    this.priceListCategories.forEach(priceListCategory => {
      this.splService.splDto.splCategoryDtos = this.splService.splDto.splCategoryDtos.map(sc => sc.categoryId === priceListCategory.priceListCategoryId ? { ...sc, appliedDiscount: priceListCategory.specifiedDiscount } : sc);
      this.splService.splDto.splProductDtos = this.splService.splDto.splProductDtos.map(sp => sp.currentProductDto.categoryId === priceListCategory.priceListCategoryId ? { ...sp, splDiscount: priceListCategory.specifiedDiscount > sp.currentProductDto.maxDiscountPercent ? sp.currentProductDto.maxDiscountPercent : priceListCategory.specifiedDiscount } : sp);
    });

    this.splService.splDto.splCategoryDtos = [...this.splService.splDto.splCategoryDtos];
    this.calculateAllSplPrices(this.splService.splDto);
    this.splService.splDto.splProductDtos = [...this.splService.splDto.splProductDtos];
    this.splService.splDetailsBasedOnSplNumberIsReady.next(this.splService.splDto);
  }

  ngOnDestroy(): void {
    this.splDetailsBasedOnSplNumberIsReadySubscription.unsubscribe();
  }

  private calculateAllSplPrices(splDto: SplDto): void{
    splDto.splProductDtos.forEach(item => {
      this.splService.calculateSplPrice(item);//updating splPrice upon discount change
    });
    splDto.belowFloorPrice = this.splService.calculateItemsBelowFP();
  }
}
