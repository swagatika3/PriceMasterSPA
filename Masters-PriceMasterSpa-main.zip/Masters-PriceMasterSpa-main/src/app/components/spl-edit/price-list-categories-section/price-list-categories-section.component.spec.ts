import { IUITKSelectItemProps } from '@uitk/angular';
import { of, Subject } from 'rxjs';
import { IUITKSelectItemPropsMock } from '../../../mock/models/iuitk-select-item-props.mock';
import { PriceListCategoriesDto } from '../../../models/price-list-categories-dto.model';
import { CategoryDtoMock } from '../../../mock/models/category-dto.model.mock';
import { SplCategoryDtoMock } from '../../../mock/models/spl-category-dto.model.mock';
import { SplDtoMock } from '../../../mock/models/spl-dto.model.mock';
import { CategoryDto } from '../../../models/category-dto.model';
import { SplDto } from '../../../models/spl-dto.model';
import { PriceListCategoriesSectionComponent } from './price-list-categories-section.component';
import { PriceListCategoriesDtoMock } from '../../../mock/models/price-list-categories-dto.model.mock';
import { SplProductDtoMock } from '../../../mock/models/spl-product-dto.model.mock';
import { ProductDtoMock } from '../../../mock/models/product-dto.model.mock';
import { ProductDto } from '../../../models/product-dto.model';

describe('SplCreateComponent', () => {
    let component: PriceListCategoriesSectionComponent;
    let configServiceMock: any;
    let splServiceMock: any;
    let categoryDtoMock: CategoryDto[];
    let productDtosMock: ProductDto[];
    let splDtoMock: SplDto = new SplDto();
    let categoriesListMock: IUITKSelectItemProps[];
    let priceListCategoriesMock: PriceListCategoriesDto[];
    const splDetailsBasedOnSplNumberIsReadyMock = new Subject<SplDto>();

    beforeEach(() => {
        categoryDtoMock = [new CategoryDtoMock()
            .withId(1)
            .withCategoryNumber('01')
            .withCategoryDescription('First Category')
            .model(),
        new CategoryDtoMock()
            .withId(2)
            .withCategoryNumber('02')
            .withCategoryDescription('Second Category')
            .model()
        ];
        productDtosMock = [new ProductDtoMock()
            .withProductId(1)
            .withCategoryId(1)
            .withProductCode('testProduct1')
            .withDescription('testProduct1')
            .withMaxDiscountPercent(100)
            .model(),
        new ProductDtoMock()
            .withProductId(2)
            .withCategoryId(2)
            .withProductCode('testProduct2')
            .withDescription('testProduct2')
            .withMaxDiscountPercent(100)
            .model()
        ]
        splDtoMock = new SplDtoMock()
            .withSplCategoryDtos([new SplCategoryDtoMock()
                .withCategoryId(1)
                .withAppliedDiscount(10)
                .model(),
            new SplCategoryDtoMock()
                .withCategoryId(2)
                .withAppliedDiscount(20)
                .model()
            ])
            .withSplProductDtos([new SplProductDtoMock()
                .withCurrentProductDto(new ProductDtoMock()
                    .withCategoryId(1)
                    .model()
                )
                .model()
            ])
            .model();
        categoriesListMock = [new IUITKSelectItemPropsMock()
            .withId('01')
            .withLabel('01 - First Category')
            .withValue('01 - First Category')
            .model(),
        new IUITKSelectItemPropsMock()
            .withId('02')
            .withLabel('02 - Second Category')
            .withValue('02 - Second Category')
            .model()
        ];
        priceListCategoriesMock = [new PriceListCategoriesDtoMock()
            .withPriceListCategoryId(1)
            .withPriceListCategory('01 - First Category')
            .withSpecifiedDiscount(25)
            .model(),
        new PriceListCategoriesDtoMock()
            .withPriceListCategoryId(2)
            .withPriceListCategory('02 - Second Category')
            .withSpecifiedDiscount(50)
            .model()
        ]
        configServiceMock = {
            categoryDtos: categoryDtoMock,
            productDtos: productDtosMock
        };

        splServiceMock = {
            splDto: splDtoMock,
            splDetailsBasedOnSplNumberIsReady: splDetailsBasedOnSplNumberIsReadyMock,
            calculateSplPrice:jest.fn(),
            calculateItemsBelowFP:jest.fn()
        };

        component = new PriceListCategoriesSectionComponent(configServiceMock, splServiceMock);
    });

    it('should create PriceListCategoriesSectionComponent', () => {
        expect(component).toBeTruthy();
    });

    describe('ngOnInit', () => {
        it('should test ngOnInit', () => {
            component.ngOnInit();
            splDetailsBasedOnSplNumberIsReadyMock.next();
            expect(component).toBeTruthy();
        });
    });

    describe('setPanelForPriceListCategories', () => {
        it('should test setPanelForPriceListCategories with priceListCategoriesPanelClass as uitk-l-grid-open', () => {
            component.priceListCategoriesPanelClass = 'uitk-l-grid-open';
            component.setPanelForPriceListCategories();
            expect(component).toBeTruthy();
        });

        it('should test setPanelForPriceListCategories with priceListCategoriesPanelClass as uitk-l-grid1-close', () => {
            component.priceListCategoriesPanelClass = 'uitk-l-grid1-close';
            component.setPanelForPriceListCategories();
            expect(component).toBeTruthy();
        });
    });

    describe('addNewCategory', () => {
        it('should test addNewCategory', () => {
            component.addNewCategory();
            expect(component).toBeTruthy();
        });
    });

    describe('deletePriceListCategory', () => {
        it('should test deletePriceListCategory', () => {
            component.priceListCategories = priceListCategoriesMock;
            component.categoriesList = categoriesListMock;
            component.deletePriceListCategory(0, 1);
            expect(component).toBeTruthy();
        });
    });

    describe('onChangeCategory', () => {
        it('should test onChangeCategory', () => {
            component.priceListCategories = priceListCategoriesMock;
            component.categoriesList = categoriesListMock;
            component.onChangeCategory(categoriesListMock[0], 0, 1);
            expect(component).toBeTruthy();
        });
    });

    describe('categoryWiseApplyDiscount', () => {
        it('should test categoryWiseApplyDiscount', () => {
            component.priceListCategories = priceListCategoriesMock;
            component.categoriesList = categoriesListMock;
            component.categoryWiseApplyDiscount(priceListCategoriesMock[0]);
            expect(component).toBeTruthy();
        });

        it('should test categoryWiseApplyDiscount with discount greater than max discount percent', () => {
            component.priceListCategories = priceListCategoriesMock;
            component.categoriesList = categoriesListMock;
            priceListCategoriesMock[0].specifiedDiscount = 200;
            component.categoryWiseApplyDiscount(priceListCategoriesMock[0]);
            expect(component).toBeTruthy();
        });
    });

    describe('overallApplyDiscount', () => {
        it('should test overallApplyDiscount', () => {
            component.overallDiscount = 50;
            component.priceListCategories = priceListCategoriesMock;
            component.overallApplyDiscount();
            expect(component).toBeTruthy();
        });

        it('should test overallApplyDiscount with overall discount greater than max discount percent', () => {
            component.overallDiscount = 150;
            component.priceListCategories = priceListCategoriesMock;
            component.overallApplyDiscount();
            expect(component).toBeTruthy();
        });
    });

    describe('applyAllDiscount', () => {
        it('should test applyAllDiscount', () => {
            component.priceListCategories = priceListCategoriesMock;
            component.applyAllDiscount();
            expect(component).toBeTruthy();
        });
    });

    describe('ngOnDestroy', () => {
        it('should test ngOnDestroy', () => {
            component['splDetailsBasedOnSplNumberIsReadySubscription'] = of().subscribe();
            component.ngOnDestroy();
            expect(component).toBeTruthy();
        });
    });
});
