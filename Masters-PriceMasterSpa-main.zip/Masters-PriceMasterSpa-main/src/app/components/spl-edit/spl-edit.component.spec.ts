import { SplCategoryDto } from 'src/app/models/spl-category-dto.model';
import { SplDtoMock } from '../../mock/models/spl-dto.model.mock';
import { SplDto } from '../../models/spl-dto.model';
import { SplEditComponent } from './spl-edit.component';

describe('SplEditComponent', () => {
  let component: SplEditComponent;
  let mockSplService: any;
  const mockSplDto: SplDto = new SplDtoMock()
    .withAccountId(1)
    .withSplName('SPL_1')
    .withEffectiveDate(new Date())
    .withSplYear(2022)
    .withSplCategoryDtos([{categoryId: 1, appliedDiscount: 0}])
    .model();

  beforeAll(() => {
    mockSplService = {
      splDto: mockSplDto
    }
  component = new SplEditComponent(mockSplService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
