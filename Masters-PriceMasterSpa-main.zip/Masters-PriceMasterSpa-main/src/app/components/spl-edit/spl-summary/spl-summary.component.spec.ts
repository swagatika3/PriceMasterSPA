import { SplSummaryComponent } from './spl-summary.component';

describe('SplSummaryComponent', () => {
  let component: SplSummaryComponent;
  let activatedRouteMock: any;
  let splServiceMock: any;

  beforeEach(() => {
    activatedRouteMock = {};
    splServiceMock = {};
    splServiceMock = {};
    component = new SplSummaryComponent(activatedRouteMock, splServiceMock);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
