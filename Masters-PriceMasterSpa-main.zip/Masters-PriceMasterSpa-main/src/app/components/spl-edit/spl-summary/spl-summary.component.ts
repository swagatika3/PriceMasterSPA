import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SplService } from '../../../services/spl.service';

@Component({
  selector: 'app-spl-summary',
  templateUrl: './spl-summary.component.html',
  styleUrls: ['./spl-summary.component.scss']
})

export class SplSummaryComponent implements OnInit {
  constructor(
    private activatedRoute: ActivatedRoute,
    public splService: SplService) {
  }

  ngOnInit(): void {
    this.splService.getSplDetailsBasedOnSplNumber(this.activatedRoute.snapshot.params['id']);
  }
}
