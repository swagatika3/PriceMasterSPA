import { Component } from '@angular/core';
import { Mode } from '../../enums/mode.enum';
import { ModeService } from '../../services/mode.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss']
})
export class MenuComponent {
  isImpersonated = false;
  impersonateType = '';
  Mode = Mode;
  loggedUserName = '';
  roleName = '';
  msId = '';

  constructor(public modeService: ModeService) { }
}
