import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ModeService } from '../../services/mode.service';

import {  MenuComponent } from './menu.component';

describe('MenuComponent', () => {
  let component: MenuComponent;
  let fixture: ComponentFixture<MenuComponent>;
  let mockModeService: any;

  beforeAll(() => {
    mockModeService = ModeService;
    component = new MenuComponent(mockModeService);
  });


  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
