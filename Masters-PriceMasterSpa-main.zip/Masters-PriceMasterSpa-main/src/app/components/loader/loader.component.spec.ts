import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoaderComponent } from './loader.component';

describe('LoaderComponent', () => {
  let component: LoaderComponent;
  let fixture: ComponentFixture<LoaderComponent>;

  beforeAll(() => {
    component = new LoaderComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
    expect(component.visibleTextValue).toEqual("Loading…");
  });
});
