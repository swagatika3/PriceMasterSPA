import { HomeComponent } from './home.component';

describe('HomeComponent', () => {
  let component: HomeComponent;
  let routerMock: any;
  let configServiceMock: any;
  let url = new String();

  beforeEach(() => {
    routerMock = {
      navigate: jest.fn()
    };

    configServiceMock = {
      spaUrl: url
    };

    component = new HomeComponent(routerMock, configServiceMock);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('createSpl', () => {
    it('should test createSpl method whether it navigates to /spl-new page', () => {
      component.accountId = "123";
      jest.spyOn(window, 'open').mockImplementationOnce(() => (configServiceMock));
      component.createSpl();
      expect(component).toBeTruthy();
    });
  });

  describe('createNextYearSpl', () => {
    it('should test createNextYearSpl', () => {
      component.accountId = "123";
      jest.spyOn(window, 'open').mockImplementationOnce(() => (configServiceMock));
      component.createNextYearSpl();
      expect(component).toBeTruthy();
    });
  });

  describe('editSpl', () => {
    it('should test editSpl method whether it navigates to /spl page', () => {
      component.splNumber = "123";
      jest.spyOn(window, 'open').mockImplementationOnce(() => (configServiceMock));
      component.editSpl();
      expect(component).toBeTruthy();
    });
  });
});
