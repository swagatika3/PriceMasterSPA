import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ConfigService } from '../../services/config.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {
  accountId = ''
  splNumber = ''

  constructor(private router: Router, private configService: ConfigService) {
  }

  createSpl(): void {
    window.open(`${this.configService.spaUrl}spl-new/${this.accountId}`); 
  }

  createNextYearSpl(): void {
    window.open(`${this.configService.spaUrl}spl-new/${this.accountId}?nextyear=true`); 
  }

  editSpl(): void {
    window.open(`${this.configService.spaUrl}spl/${this.splNumber}`);    
  }
}
