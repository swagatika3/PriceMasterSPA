import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { IUITKSelectItemProps } from '@uitk/angular';
import { Subscription } from 'rxjs';
import { CreateSplDto } from '../../models/create-spl-dto.model';
import { SplNumberDto } from '../../models/spl-number-dto.model';
import { Mode } from '../../enums/mode.enum';
import { AccountHeaderDto } from '../../models/account-header-dto.model';
import { CategoryDto } from '../../models/category-dto.model';
import { ConfigService } from '../../services/config.service';
import { ModeService } from '../../services/mode.service';
import { SplCreateService } from '../../services/spl-create.service';
import { SplService } from '../../services/spl.service';
import { SplMode } from '../../enums/splmode.enum';


@Component({
  selector: 'app-spl-create',
  templateUrl: './spl-create.component.html',
  styleUrls: ['./spl-create.component.scss']
})
export class SplCreateComponent implements OnInit, OnDestroy {
  accountIdCloneDialog = { show: false };
  columnCount = 3;
  rowCount = 0;
  columns: number[] = [];
  rows: number[] = [];
  categoriesAreReadySubscription: Subscription | undefined;
  accountHeaderIsReadySubscription: Subscription | undefined;
  accountId = 0;
  selectAllPriceList = false;
  Mode = Mode;

  currentYear = new Date().getFullYear().toString();
  futureyear = (+this.currentYear + 1).toString();
  listYear: IUITKSelectItemProps[] = [
    { id: '1', label: this.currentYear, value: this.currentYear.toString() },
    { id: '2', label: this.futureyear, value: this.futureyear.toString() }
  ];
  listYearFilter = this.listYear.filter(l => l.label === this.futureyear)[0];
  todayDate = new Date();
  categories: CategoryDto[] = [];
  accountHeader: AccountHeaderDto = new AccountHeaderDto();
  overrideCorporatePricing = false;
  selectedCategories: number[] = [];

  constructor(private route: ActivatedRoute,
    private splCreateService: SplCreateService,
    public configService: ConfigService,
    public splService: SplService,
    public modeService: ModeService,
    private router: Router) {
  }

  ngOnInit(): void {
    if (this.route.snapshot.params.id) {
      this.accountId = parseInt(this.route.snapshot.params.id);
    }

    this.route.queryParams.subscribe((params) => {
      if (params.nextyear === 'true') {
        this.listYearFilter = this.listYear.filter(l => l.label === this.futureyear)[0];

        this.splService.createNextYearSpl(this.accountId).subscribe((data: SplNumberDto) => {
          this.configService.splMode = SplMode.CreateNextYearSpl;
          this.router.navigate(['/spl', data.splNumber]);
        });
      }
    });
    this.configService.splMode = SplMode.CreateSpl;
    this.categories = this.configService.categoryDtos;
    if(this.splService.splDto.splCategoryDtos.length > 0)
    {
      this.splService.splDto.splCategoryDtos.forEach(element => {
      const category =   this.categories.filter(c=>c.id===element.categoryId)[0];
      category.isSelected = true;
      this.selectedCategories.push(category.id);
      });
    }
    if(this.splService.splDto.splYear !==0)
    {
      this.listYearFilter = this.listYear.filter(l => l.value === this.splService.splDto.splYear.toString())[0];
    }
    this.splService.splDto.accountId = this.accountId;
    this.splCreateService.getAccountHeader(this.accountId);
    this.modeService.mode = Mode.Edit;

    this.accountHeaderIsReadySubscription = this.splCreateService.accountHeaderIsReady.subscribe((data: AccountHeaderDto) => {
      this.accountHeader = data;
      this.splService.splDto.accountHeaderDto = this.accountHeader;
      this.disableOverrideCheckBox();
      this.updatePriceListCategoryList();
    }, () => {
      alert('Error occurred while getting Account Header information');
    });
  }
 
  changeOverride(): void {
    if (this.overrideCorporatePricing === false) {
      alert('Corporate Pricing will be applied unless you check the Override Corporate Pricing checkbox');
      window.close();
    }
  }

  disableOverrideCheckBox(): void {
    this.overrideCorporatePricing = this.splService.splDto.accountHeaderDto?.corporateAccountId && this.splService.splDto.accountHeaderDto?.hasCorporatePricing ? true : false;
  }

  updatePriceListCategoryList(): void {
    if (this.categories.length > 0 && this.accountId > 0) {
      if (this.accountHeader?.accountType !== 'C') {
        this.categories = this.categories.filter(item => item.accountTypeCode !== 'C');
      }
      this.rowCount = Math.ceil(this.categories.length / this.columnCount);

      this.rows = [];
      for (let i = 0; i < this.rowCount; i++) {
        this.rows.push(i);
      }

      this.columns = [];
      for (let i = 0; i < this.columnCount; i++) {
        this.columns.push(i);
      }
    }
  }

  create(): void {
    const createSplDto: CreateSplDto = new CreateSplDto();
    createSplDto.accountId = this.accountId;
    createSplDto.splYear = +this.listYearFilter.label;
    createSplDto.categoryIds = this.selectedCategories;

    this.splService.createSpl(createSplDto).subscribe((data: SplNumberDto) => {
      this.router.navigate(['/spl', data.splNumber]);
    }, (error: Error) => {
      console.log(error);
      alert('Unable to Create SPL');
    });
  }

  selectedCategory(column: number, rowCount: number, row: number): void {
    const selectAll = !this.categories.some(item => !item.isSelected);
    this.selectAllPriceList = selectAll;
    const isCategoryAvailable = this.selectedCategories.includes(this.categories[column * rowCount + row].id);

    if (!isCategoryAvailable) {
      this.selectedCategories.push(this.categories[column * rowCount + row].id);
    }
    else {
      const index = this.selectedCategories.indexOf(this.categories[column * rowCount + row].id);
      this.selectedCategories.splice(index, 1);
    }

    console.log(this.selectedCategories);
  }

  selectAll(): void {
    this.splService.splDto.splCategoryDtos = [];
    const selectAll = this.categories.some(item => !item.isSelected);

    for (let i = 0; i < this.categories.length; i++) {
      this.categories[i].isSelected = selectAll;
      this.selectedCategories.push(this.categories[i].id);
    }
  }

  clear(): void {
    for (let i = 0; i < this.categories.length; i++) {
      this.categories[i].isSelected = false;
    }

    this.selectAllPriceList = false;
    this.selectedCategories = [];
  }

  ngOnDestroy(): void {
    this.categoriesAreReadySubscription?.unsubscribe();
    this.accountHeaderIsReadySubscription?.unsubscribe();
  }
}
