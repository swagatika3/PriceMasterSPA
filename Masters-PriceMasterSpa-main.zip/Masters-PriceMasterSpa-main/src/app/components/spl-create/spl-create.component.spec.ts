
import { EMPTY, of, Subject } from 'rxjs';
import { AccountHeaderDtoMock } from '../../mock/models/account-header-dto.model.mock';
import { CategoryDtoMock } from '../../mock/models/category-dto.model.mock';
import { SplDtoMock } from '../../mock/models/spl-dto.model.mock';
import { AccountHeaderDto } from '../../models/account-header-dto.model';
import { CategoryDto } from '../../models/category-dto.model';
import { SplDto } from '../../models/spl-dto.model';
import { ModeService } from '../../services/mode.service';
import { SplCreateComponent } from './spl-create.component';


describe('SplCreateComponent', () => {
  let component: SplCreateComponent;
  let mockModeService: any;
  let mockConfigService: any;
  let activatedRouteMock: any;
  let mockSplCreateService: any;
  let mockSplService: any;
  let event: any;
  let routerMock: any

  const mockConfigIsReady = new Subject();
  const mockCategoriesAreReady = new Subject<CategoryDto[]>();
  const mockAccountHeaderIsReady = new Subject<AccountHeaderDto>();
  


  const categories: CategoryDto[] = [new CategoryDtoMock()
    .withId(1)
    .withCategoryNumber('01')
    .withCategoryDescription('Physician ICD-10-CM')
    .withAccountTypeCode('O')
    .withIsSelected(false)
    .model(),
  new CategoryDtoMock().withId(22)
    .withCategoryNumber('31')
    .withCategoryDescription('Partner Book Only')
    .withAccountTypeCode('C')
    .withIsSelected(false)
    .model()]

  const accountHeader: AccountHeaderDto = new AccountHeaderDtoMock()
    .withAccountName('Tasha Tyrell-Williams LCSW-R')
    .withSalesforceId('0010x00000I91SxAAJ')
    .withCorporateName(null)
    .withCorporateSalesforceId(null)
    .withCorporateAccountId(null)
    .withaccountType('O')
    .withhasCorporatePricing(false)
    .model()

  const mockSplDto: SplDto = new SplDtoMock()
    .withAccountId(1)
    .withSplName('SPL_1')
    .withEffectiveDate(new Date())
    .withSplYear(2022)
    .withSplCategoryDtos([{categoryId: 1, appliedDiscount: 0}])
    .model();

  beforeAll(() => {
    mockModeService = ModeService;
    mockConfigService = {
      configIsReady: mockConfigIsReady,
      loadConfigurations: jest.fn(),
      categoryDtos: categories
    }
    mockSplCreateService = {
      categoriesAreReady: mockCategoriesAreReady,
      getCategories: jest.fn().mockReturnValue(categories),
      accountHeaderIsReady: mockAccountHeaderIsReady,
      getAccountHeader: jest.fn().mockReturnValue(accountHeader)
    }
    mockSplService = {
      splDto: mockSplDto,
      createSpl: jest.fn().mockReturnValue(of(123456))
    }
    activatedRouteMock = {
      snapshot: {
        params: {
          id: '123456'
        }
      },
      queryParams: of({ nextyear: 'true' })
    };
    routerMock = {
      navigate: jest.fn()
    };

    component = new SplCreateComponent(activatedRouteMock, mockSplCreateService, mockConfigService, mockSplService, mockModeService, routerMock);
  });

  it('should create SplCreateComponent', () => {
    expect(component).toBeTruthy();
  });

  describe('Page Life Cycle Hooks', () => {
    it('should test ngOnInit', () => {
      component.ngOnInit();
      mockConfigIsReady.next();
      mockCategoriesAreReady.next(categories);
      mockAccountHeaderIsReady.next(accountHeader);
      expect(component.categories.length).toEqual(1);
      accountHeader.accountType = 'C';
      mockConfigIsReady.next();
      mockCategoriesAreReady.next(categories);
      mockAccountHeaderIsReady.next(accountHeader);
      expect(component).toBeTruthy();
    });
    it('should unsubscribe when ngOnDestroy', () => {
      component['categoriesAreReadySubscription'] = of().subscribe();
      const unsubscriptionSpy1 = jest.spyOn(component['categoriesAreReadySubscription'], 'unsubscribe');
      component['accountHeaderIsReadySubscription'] = of().subscribe();
      const unsubscriptionSpy2 = jest.spyOn(component['accountHeaderIsReadySubscription'], 'unsubscribe');
      component.ngOnDestroy();
      expect(unsubscriptionSpy1).toHaveBeenCalled();
      expect(unsubscriptionSpy2).toHaveBeenCalled();
    });
  });
  it('should test selectAll', () => {
    component.categories = categories;
    component.selectAllPriceList = true;
    component.selectAll();
    expect(component).toBeTruthy();
  });

  it('should test clear', () => {
    component.categories = categories;
    component.selectAllPriceList = true;
    component.clear();
    expect(component.selectAllPriceList).toBeFalsy();
    expect(component.splService.splDto.splCategoryDtos.length).toEqual(0);
  });

  it('should test disableOverrideCheckBox', () => {
    component.disableOverrideCheckBox();
    expect(component.overrideCorporatePricing).toBeFalsy;
    
  });
  it('should test changeOverride', () => {
   
    jest.spyOn(window, 'alert').mockImplementation(() => of(EMPTY));
     jest.spyOn(window, 'close').mockImplementation(() => of(EMPTY));
    component.overrideCorporatePricing = false;
    component.changeOverride();
    expect(component).toBeTruthy();
    
  });
  it('should test create', () => {
    const spy1 = jest.spyOn(mockSplService, 'createSpl');
    component.create(); 
    expect(spy1).toHaveBeenCalled();
    
  });


});
