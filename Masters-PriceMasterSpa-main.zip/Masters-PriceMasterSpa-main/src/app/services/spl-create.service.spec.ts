import { EMPTY, of, throwError } from 'rxjs';
import { AccountHeaderDto } from '../models/account-header-dto.model';
import { CategoryDto } from '../models/category-dto.model';
import { SplCreateService } from "./spl-create.service";

describe("SplCreateService", () => {
  let service: SplCreateService;
  let mockConfigService: any;
  let mockHttpClient: any;
  let mockUrl: any;
  let mockPriceListCategories: CategoryDto[] =[];
  let mockAccountHeader: AccountHeaderDto = new AccountHeaderDto();

  beforeAll(() => {
    mockHttpClient = {
      post: jest.fn(),
      get: jest.fn()
    };
    mockConfigService = {
      apiUrl: mockUrl
    };
    service = new SplCreateService(mockHttpClient, mockConfigService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should test getAccountHeader method', () => {
    jest.spyOn(mockHttpClient, 'get').mockImplementation(() => of(mockAccountHeader));
    service.getAccountHeader(123);
    expect(service.accountHeaderDto).toEqual(mockAccountHeader);
  });

  it('should test getAccountHeader method for any exception', () => {
    jest.spyOn(mockHttpClient, 'get').mockImplementation(() => { return throwError(new Error('System.ArgumentException: Unable to find AccountHeader')); });
    jest.spyOn(window, 'alert').mockImplementation(() => of(EMPTY));
    service.getAccountHeader(123);
    expect(window.alert).toBeCalledWith('An error occurred while getting AccountHeader information. Please try again.');
  });
});
