import { HttpClient } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';

import { ConfigService } from "./config.service";

describe("ConfigService", () => {
  let service: any;
  let mockHttpClient: any;
  let modeService: any;

  beforeAll(() => {
    service = new ConfigService(mockHttpClient, modeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
