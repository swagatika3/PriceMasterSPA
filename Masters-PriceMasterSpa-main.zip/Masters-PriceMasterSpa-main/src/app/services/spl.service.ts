import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of, Subject } from 'rxjs';
import { finalize, share, tap } from 'rxjs/operators';
import { CreateSplDto } from '../models/create-spl-dto.model';
import { SplApprovalDto } from '../models/spl-approval-dto.model';
import { SplDto } from '../models/spl-dto.model';
import { SplNumberDto } from '../models/spl-number-dto.model';
import { SplProductDto } from '../models/spl-product-dto.model';
import { UserGridPreferenceDto } from '../models/user-grid-preference-dto.model';
import { ConfigService } from './config.service';

@Injectable({
  providedIn: 'root'
})

export class SplService {
  splDto: SplDto = new SplDto();
  splDetailsBasedOnSplNumberIsReady = new Subject<SplDto>();
  splDetailsBasedOnSplNumberCache!: SplDto | null;
  splDetailsBasedOnSplNumberCachedObservable!: Observable<SplDto> | null;
  userGridPreferenceCache!: UserGridPreferenceDto | null;
  userGridPreferenceCachedObservable!: Observable<UserGridPreferenceDto> | null;
  splApprovalsCache!: SplApprovalDto[] | null;
  splApprovalsCachedObservable!: Observable<SplApprovalDto[]> | null;

  constructor(private httpClient: HttpClient, private configService: ConfigService) {
  }

  getSplDetailsBasedOnSplNumber(splNumber: number): void {
    let observable: Observable<SplDto>;

    if (this.splDetailsBasedOnSplNumberCache) {
      observable = of(this.splDetailsBasedOnSplNumberCache);
    }
    else if (this.splDetailsBasedOnSplNumberCachedObservable) {
      observable = this.splDetailsBasedOnSplNumberCachedObservable;
    }
    else {
      this.splDetailsBasedOnSplNumberCachedObservable = this.httpClient.get<SplDto>(`${this.configService.apiUrl}/Spl/GetSpl/${splNumber}`)
        .pipe(
          tap((response: SplDto) => {
            this.splDetailsBasedOnSplNumberCache = response;
          }),
          share(),
          finalize(() => {
            this.splDetailsBasedOnSplNumberCache = null;
            this.splDetailsBasedOnSplNumberCachedObservable = null;
          })
        );

      observable = this.splDetailsBasedOnSplNumberCachedObservable;
    }

    observable.subscribe((data: SplDto) => {
      this.splDto = data;
      this.refreshFields();
      this.splDetailsBasedOnSplNumberIsReady.next(this.splDto);
    }, (error: Error) => {
      console.log(error);
      alert('An error occurred while getting spl information. Please try again.');
    });
  }

  createSpl(createSplDto: CreateSplDto): Observable<SplNumberDto> {
    return this.httpClient.post<SplNumberDto>(`${this.configService.apiUrl}/Spl/CreateSpl`, createSplDto);
  }

  createNextYearSpl(accountId: number): Observable<SplNumberDto> {
    return this.httpClient.get<SplNumberDto>(`${this.configService.apiUrl}/Spl/CreateNextYearSpl/${accountId}`);
  }

  getUserPreferences(userId: string, gridName: string): Observable<UserGridPreferenceDto> {
    let observable: Observable<UserGridPreferenceDto>;

    if (this.userGridPreferenceCache) {
      observable = of(this.userGridPreferenceCache);
    }
    else if (this.userGridPreferenceCachedObservable) {
      observable = this.userGridPreferenceCachedObservable;
    }
    else {
      this.userGridPreferenceCachedObservable = this.httpClient.get<UserGridPreferenceDto>(`${this.configService.apiUrl}/spl/getuserpreferences?userId=${userId}&gridName=${gridName}`)
        .pipe(
          tap((response: UserGridPreferenceDto) => {
            this.userGridPreferenceCache = response;
          }),
          share(),
          finalize(() => {
            this.userGridPreferenceCache = null;
            this.userGridPreferenceCachedObservable = null;
          })
        );

      observable = this.userGridPreferenceCachedObservable;
    }

    return observable;
  }

  saveSpl(splDto: SplDto): Observable<SplNumberDto> {
    return this.httpClient.post<SplNumberDto>(`${this.configService.apiUrl}/Spl/SaveSpl`, splDto);
  }

  saveUserPreferences(userGridPreferenceDto: UserGridPreferenceDto): Observable<UserGridPreferenceDto> {
    return this.httpClient.post<UserGridPreferenceDto>(`${this.configService.apiUrl}/Spl/SaveUserPreferences`, userGridPreferenceDto);
  }

  refreshFields(): void {
    /*this.splDto.splProductDtos.forEach(item => {
      this.calculateDiscount(item);
    });*/ //Commenting this as this is causing to load invalid discount values during page load.

    const statusMap = [ 
        { code: 'W', label: 'WIP'},
        { code: 'D', label: 'Draft'},
        { code: 'P', label: 'Pending Approval'},
        { code: 'R', label: 'Rejected'},
        { code: 'A', label: 'Approved'},
      ];

    this.splDto.statusDescription = statusMap.filter(item => item.code == this.splDto.statusCode)[0]?.label;
    this.splDto.belowFloorPrice = this.calculateItemsBelowFP();
    this.splDetailsBasedOnSplNumberIsReady.next(this.splDto);
    this.splDto.splProductDtos = [...this.splDto.splProductDtos];
    this.calculateProjectedTotals();
  }

  calculateItemsBelowFP(): string {
    // Calculate items below floor price.
    const itemArray = this.splDto.splProductDtos
      .filter(item => item.splPrice < (item.currentProductDto.priceCatalogDto?.floorPrice ?? 0))
      .map(item => item.currentProductDto.productCode);

    return itemArray.join(', ');
  }

  calculateProjectedTotals(): void {
    // Projected % of Target = 100 * sum (Quantity * Specified Unit Price) / sum (Quantity * Sales Target Price)
    this.splDto.projectedPercentOfTarget =
      isNaN(this.splDto.splProductDtos.reduce((sum, item) => sum + item.quantity * item.splPrice, 0) /
        this.splDto.splProductDtos.reduce((sum, item) => sum + item.quantity * (item.currentProductDto.priceCatalogDto?.targetPrice ?? 0), 0)) ? 0 : this.splDto.splProductDtos.reduce((sum, item) => sum + item.quantity * item.splPrice, 0) /
      this.splDto.splProductDtos.reduce((sum, item) => sum + item.quantity * (item.currentProductDto.priceCatalogDto?.targetPrice ?? 0), 0);

    // Projected Total Sales Amt = sum (Quantity * Specified Unit Price) 
    this.splDto.projectedTotalSalesAmount = this.splDto.splProductDtos.reduce((sum, item) => sum + item.quantity * item.splPrice, 0);

    // Review the Projected Total Margin Amt. = sum (Quantity * (Specified Unit Price - Sales Floor Price))
    this.splDto.projectedTotalMarginAmount = this.splDto.splProductDtos.reduce((sum, item) => sum + item.quantity * (item.splPrice - (item.currentProductDto.priceCatalogDto?.floorPrice ?? 0)), 0);
  }

  calculateSplPrice(product: SplProductDto): void {
    product.splPrice = Math.round(((product.currentProductDto.priceCatalogDto?.listPrice ?? 0) * (100 - product.splDiscount) / 100) * 100) / 100;
  }

  calculateDiscount(product: SplProductDto): void {
    product.splDiscount = (product.currentProductDto.priceCatalogDto?.listPrice ?? 0) === 0 ? 0 : Math.round((100 - product.splPrice / (product.currentProductDto.priceCatalogDto?.listPrice ?? 0) * 100) * 1000) / 1000;
  }

  getApprovals(splHeaderId: number): Observable<SplApprovalDto[]> {
    let observable: Observable<SplApprovalDto[]>;

    if (this.splApprovalsCache) {
      observable = of(this.splApprovalsCache);
    }
    else if (this.splApprovalsCachedObservable) {
      observable = this.splApprovalsCachedObservable;
    }
    else {
      this.splApprovalsCachedObservable = this.httpClient.get<SplApprovalDto[]>(`${this.configService.apiUrl}/spl/getapprover/${splHeaderId}`)
        .pipe(
          tap((response: SplApprovalDto[]) => {
            this.splApprovalsCache = response;
          }),
          share(),
          finalize(() => {
            this.splApprovalsCache = null;
            this.splApprovalsCachedObservable = null;
          })
        );

      observable = this.splApprovalsCachedObservable;
    }

    return observable;
  }
}
