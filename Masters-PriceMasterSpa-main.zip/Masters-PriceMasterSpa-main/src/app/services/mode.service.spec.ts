import { ModeService } from './mode.service';

describe('ModeService', () => {
  let service: ModeService;

  beforeAll(() => {
    service = new ModeService();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
