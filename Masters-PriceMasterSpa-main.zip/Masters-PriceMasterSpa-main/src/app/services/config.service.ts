import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { CategoryDto } from '../models/category-dto.model';
import { ConfigDto } from '../models/config-dto.model';
import { ProductDto } from '../models/product-dto.model';
import { ReferenceDto } from '../models/reference-dto.model';
import { ModeService } from './mode.service';
import { SplMode } from '../enums/splmode.enum';

@Injectable({
  providedIn: 'root'
})
export class ConfigService {
  configIsReady = new Subject();
  spaUrl = '';
  apiUrl = '';
  environment = '';
  productDtos: ProductDto[] = [];
  categoryDtos: CategoryDto[] = [];
  splMode: SplMode = SplMode.EditSpl;

  constructor(
    private httpClient: HttpClient,
    private modeService: ModeService
    ) {
  }

  // The load method gets called from the app initializer and angular will not let other code run until this promise is complete.
  async load(): Promise<void> {    
    return new Promise(resolve => {      
      this.loadEnvironment(resolve);
    });
  }

  private loadEnvironment(resolve: (value: void | PromiseLike<void>) => void) {
    this.httpClient.get<{ environment: string }>('assets/config/environment.json').subscribe((file: { environment: string }) => {
      this.environment = file.environment;
      const environments = ['Local', 'Development', 'Test', 'Staging', 'Production'];

      if (!environments.some(e => e === this.environment)) {
        alert('Invalid environment file is setup');
        resolve();
      }

      this.loadAppSettings(resolve);
    }, error => {
      console.log(error);
      alert('Unable to get environment details.');
      resolve();
    });
  }

  private loadAppSettings(resolve: (value: void | PromiseLike<void>) => void): void {
    this.httpClient.get<ConfigDto>(`assets/config/appsettings.${this.environment}.json`).subscribe((configDto: ConfigDto) => {
      this.spaUrl = configDto.spaUrl;
      this.apiUrl = configDto.apiUrl;
      this.loadReferences(resolve);
    }, error => {
      console.log(error);
      alert('Unable to get appsetting file.');
      resolve();
    });
  }

  private loadReferences(resolve: (value: void | PromiseLike<void>) => void): void {
    this.httpClient.get<ReferenceDto>(`${this.apiUrl}/Reference/GetReferences`).subscribe((referenceDto: ReferenceDto) => {
      this.productDtos = referenceDto.productDtos;
      this.categoryDtos = referenceDto.categoryDtos;
      resolve();
    });
  }

  getMyMSId(): string {
    let currentUser = JSON.parse(localStorage.getItem('currentUser') as any);
    return currentUser?.profile.preferred_username ?? 'sgaddam1';
  }
}
