import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of, Subject } from 'rxjs';
import { finalize, share, tap } from 'rxjs/operators';
import { AccountHeaderDto } from '../models/account-header-dto.model';
import { CreateSplDto } from '../models/create-spl-dto.model';
import { SplDto } from '../models/spl-dto.model';
import { SplNumberDto } from '../models/spl-number-dto.model';
import { ConfigService } from './config.service';

@Injectable({
  providedIn: 'root'
})
export class SplCreateService {
  accountHeaderDto: AccountHeaderDto = new AccountHeaderDto();
  accountHeaderIsReady = new Subject<AccountHeaderDto>();
  private readonly _configService: ConfigService;
  private readonly _httpClient: HttpClient;
  private accountHeaderCache!: AccountHeaderDto | null;
  private accountHeaderCachedObservable!: Observable<AccountHeaderDto> | null;

  constructor(httpClient: HttpClient, configService: ConfigService) {
    this._httpClient = httpClient;
    this._configService = configService;
  }

  getAccountHeader(accountId: number): void {
    let observable: Observable<AccountHeaderDto>;

    if (this.accountHeaderCache) {
      observable = of(this.accountHeaderCache);
    }
    else if (this.accountHeaderCachedObservable) {
      observable = this.accountHeaderCachedObservable;
    }
    else {
      this.accountHeaderCachedObservable = this._httpClient.get<AccountHeaderDto>(`${this._configService.apiUrl}/Spl/GetAccountHeader/${accountId}`)
        .pipe(
          tap((response: AccountHeaderDto) => {
            this.accountHeaderCache = response;
          }),
          share(),
          finalize(() => {
            this.accountHeaderCache = null;
            this.accountHeaderCachedObservable = null;
          })
        );

      observable = this.accountHeaderCachedObservable;
    }

    observable.subscribe((data: AccountHeaderDto) => {
      this.accountHeaderDto = data;
      this.accountHeaderIsReady.next(this.accountHeaderDto);
    }, error => {
      console.log(error);
      alert('An error occurred while getting AccountHeader information. Please try again.');

    });
  }

  getSplNumberByCloneSpl(fromAccountId: number, toAccountId: number) {
    return this._httpClient.get<SplNumberDto>(`${this._configService.apiUrl}/Spl/CloneSpl/${fromAccountId}/${toAccountId}`);
  }

}
