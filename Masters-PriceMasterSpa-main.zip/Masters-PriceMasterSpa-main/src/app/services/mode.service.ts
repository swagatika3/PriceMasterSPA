import { Injectable } from '@angular/core';
import { Mode } from '../enums/mode.enum';

@Injectable({
  providedIn: 'root'
})
export class ModeService {
  mode: Mode = Mode.View;
  isWaiting = false;
  waitList: string[] = [];
  waitDescription = '';

  addToWaitList(entry: string): void {
    if (this.waitList.length === 0) {
      this.isWaiting = true;
    }

    this.waitList.push(entry);
    this.waitList = [...this.waitList];
    this.waitDescription = this.waitList[0];
  }

  removeFromWaitList(entry: string): void {
    this.waitList = this.waitList.filter(item => item !== entry);
    this.waitDescription = this.waitList[0];

    if (this.waitList.length === 0) {
      this.isWaiting = false;
    }
  }
}
