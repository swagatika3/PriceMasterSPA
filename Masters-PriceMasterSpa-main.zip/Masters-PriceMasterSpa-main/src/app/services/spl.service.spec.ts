import { of, throwError } from "rxjs";
import { CreateSplDtoMock } from "../mock/models/create-spl-dto.model.mock";
import { PriceCatalogDtoMock } from "../mock/models/price-catalog-dto.model.mock";
import { ProductDtoMock } from "../mock/models/product-dto.model.mock";
import { SplApprovalDtoMock } from "../mock/models/spl-approval-dto.model.mock";
import { SplDtoMock } from "../mock/models/spl-dto.model.mock";
import { SplNumberDtoMock } from "../mock/models/spl-number-dto.model.mock";
import { SplProductDtoMock } from "../mock/models/spl-product-dto.model.mock";
import { UserGridPreferenceDtoMock } from "../mock/models/user-grid-preference-dto.model.mock";
import { CreateSplDto } from "../models/create-spl-dto.model";
import { SplApprovalDto } from "../models/spl-approval-dto.model";
import { SplDto } from "../models/spl-dto.model";
import { SplNumberDto } from "../models/spl-number-dto.model";
import { SplProductDto } from "../models/spl-product-dto.model";
import { UserGridPreferenceDto } from "../models/user-grid-preference-dto.model";
import { SplService } from "./spl.service";

describe("SplService", () => {
  let service: SplService;
  let httpClientMock: any;
  let configServiceMock: any;
  let splDtoMock: SplDto;
  let createSplDtoMock: CreateSplDto;
  let splNumberDtoMock: SplNumberDto;
  let userGridPreferenceDtoMock: UserGridPreferenceDto;
  let splApprovalDtoMock: SplApprovalDto[];
  let splProductDtoMock: SplProductDto;

  beforeEach(() => {
    splDtoMock = new SplDtoMock()
      .withSplProductDtos([new SplProductDtoMock()
        .withSplPrice(10)
        .withQuantity(10)
        .withCurrentProductDto(new ProductDtoMock()
          .withPriceCatalogDto(null)
          .withProductCode('0050')
          .model())
        .model()
        , new SplProductDtoMock()
          .withSplPrice(5)
          .withQuantity(10)
          .withCurrentProductDto(new ProductDtoMock()
            .withPriceCatalogDto(new PriceCatalogDtoMock()
              .withFloorPrice(10)
              .withListPrice(10)
              .withTargetPrice(10)
              .model())
            .model())
          .model()
      ]).model();
    createSplDtoMock = new CreateSplDtoMock().model();
    splNumberDtoMock = new SplNumberDtoMock().model();
    userGridPreferenceDtoMock = new UserGridPreferenceDtoMock().model();
    splApprovalDtoMock = [new SplApprovalDtoMock().model()];
    splProductDtoMock = new SplProductDtoMock()
      .withSplPrice(10)
      .withSplDiscount(10)
      .withCurrentProductDto(new ProductDtoMock()
        .withPriceCatalogDto(new PriceCatalogDtoMock()
          .withListPrice(10)
          .model())
        .model()
      )
      .model();

    httpClientMock = {
      get: jest.fn(),
      post: jest.fn()
    };

    configServiceMock = {
      apiUrl: 'https://pricemasterapi-dev.appservice.ctc01.optum.com/PriceMasterApi/api'
    }

    service = new SplService(httpClientMock, configServiceMock);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('getSplDetailsBasedOnSplNumber', () => {
    it('should test getSplDetailsBasedOnSplNumber', () => {
      jest.spyOn(httpClientMock, 'get').mockImplementation(() => of(splDtoMock));
      service.getSplDetailsBasedOnSplNumber(123456);
      expect(service).toBeTruthy();
    });

    it('should test getSplDetailsBasedOnSplNumber with error', () => {
      jest.spyOn(httpClientMock, 'get').mockImplementation(() => {
        return throwError(new Error('An error occurred while getting spl information. Please try again.'));
      });
      service.getSplDetailsBasedOnSplNumber(123456);
      expect(service).toBeTruthy();
    });

    it('should test getSplDetailsBasedOnSplNumber with splDetailsBasedOnSplNumberCachedObservable', () => {
      service.splDetailsBasedOnSplNumberCachedObservable = of(splDtoMock);
      service.getSplDetailsBasedOnSplNumber(123456);
      expect(service).toBeTruthy();
    });

    it('should test getSplDetailsBasedOnSplNumber with splDetailsBasedOnSplNumberCache', () => {
      service.splDetailsBasedOnSplNumberCache = splDtoMock;
      service.getSplDetailsBasedOnSplNumber(123456);
      expect(service).toBeTruthy();
    });
  });

  describe('createSpl', () => {
    it('should test createSpl', () => {
      jest.spyOn(httpClientMock, 'post').mockImplementation(() => of(splNumberDtoMock));
      service.createSpl(createSplDtoMock);
      expect(service).toBeTruthy();
    });
  });

  describe('createNextYearSpl', () => {
    it('should test createNextYearSpl', () => {
      jest.spyOn(httpClientMock, 'get').mockImplementation(() => of(splNumberDtoMock));
      service.createNextYearSpl(123456);
      expect(service).toBeTruthy();
    });
  });

  describe('getUserPreferences', () => {
    it('should test getUserPreferences', () => {
      jest.spyOn(httpClientMock, 'get').mockImplementation(() => of(userGridPreferenceDtoMock));
      service.getUserPreferences('msunilk2', 'SplProductGrid').subscribe((data: UserGridPreferenceDto) => {
        console.log(data);
      });
      expect(service).toBeTruthy();
    });

    it('should test getUserPreferences with userGridPreferenceCachedObservable', () => {
      service.userGridPreferenceCachedObservable = of(userGridPreferenceDtoMock);
      service.getUserPreferences('msunilk2', 'SplProductGrid');
      expect(service).toBeTruthy();
    });

    it('should test getUserPreferences with userGridPreferenceCache', () => {
      service.userGridPreferenceCache = userGridPreferenceDtoMock;
      service.getUserPreferences('msunilk2', 'SplProductGrid');
      expect(service).toBeTruthy();
    });
  });

  describe('saveUserPreferences', () => {
    it('should test saveUserPreferences', () => {
      jest.spyOn(httpClientMock, 'post').mockImplementation(() => of(userGridPreferenceDtoMock));
      service.saveUserPreferences(userGridPreferenceDtoMock);
      expect(service).toBeTruthy();
    });
  });

  describe('saveSpl', () => {
    it('should test saveSpl', () => {
      jest.spyOn(httpClientMock, 'post').mockImplementation(() => of(splNumberDtoMock));
      service.saveSpl(splDtoMock);
      expect(service).toBeTruthy();
    });
  });

  describe('calculateProjectedTotals', () => {
    it('should test calculateProjectedTotals', () => {
      service.splDto = splDtoMock;
      service.calculateProjectedTotals();
      expect(service).toBeTruthy();
    });
  });

  describe('calculateSplPrice', () => {
    it('should test calculateSplPrice', () => {
      service.calculateSplPrice(splProductDtoMock);
      expect(service).toBeTruthy();
    });

    it('should test calculateSplPrice with null currentpricecatalogdto', () => {
      service.calculateSplPrice(splProductDtoMock);
      expect(service).toBeTruthy();
    });
  });

  describe('calculateDiscount', () => {
    it('should test calculateDiscount', () => {
      service.calculateDiscount(splProductDtoMock);
      expect(service).toBeTruthy();
    });

    it('should test calculateDiscount with null currentpricecatalogdto', () => {
      service.calculateDiscount(splProductDtoMock);
      expect(service).toBeTruthy();
    });
  });

  describe('getApprovals', () => {
    it('should test getApprovals', () => {
      jest.spyOn(httpClientMock, 'get').mockImplementation(() => of(splApprovalDtoMock));
      service.getApprovals(123456).subscribe((data: SplApprovalDto[]) => {
        console.log(data);
      });
      expect(service).toBeTruthy();
    });

    it('should test getApprovals with splApprovalsCachedObservable', () => {
      service.splApprovalsCachedObservable = of(splApprovalDtoMock);
      service.getApprovals(123456);
      expect(service).toBeTruthy();
    });

    it('should test getApprovals with splApprovalsCache', () => {
      service.splApprovalsCache = splApprovalDtoMock;
      service.getApprovals(123456);
      expect(service).toBeTruthy();
    });
  });
});
