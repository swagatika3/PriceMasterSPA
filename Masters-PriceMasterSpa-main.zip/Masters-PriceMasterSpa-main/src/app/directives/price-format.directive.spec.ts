import { PriceFormatDirective } from './price-format.directive';

describe('PriceFormatDirective', () => {
  let directive: PriceFormatDirective;
  let elementRefMock: any;
  let rendererMock: any;
  let currencyPipeMock: any;

  beforeEach(() => {
    elementRefMock = {};
    rendererMock = {};
    currencyPipeMock = {};

    directive = new PriceFormatDirective(elementRefMock, rendererMock, currencyPipeMock);
  });
  it('should create an instance', () => {
    expect(directive).toBeTruthy();
  });
});
