import { DiscountFormatDirective } from './discount-format.directive';

describe('DiscountFormatDirective', () => {
  let directive: DiscountFormatDirective;
  let elementRefMock: any;
  let rendererMock: any;
  let decimalPipeMock: any;

  beforeEach(() => {
    elementRefMock = {};
    rendererMock = {};
    decimalPipeMock = {};

    directive = new DiscountFormatDirective(elementRefMock, rendererMock, decimalPipeMock);
  });

  it('should create an instance', () => {
    expect(directive).toBeTruthy();
  });
});
