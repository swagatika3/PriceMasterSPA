import { QuantityFormatDirective } from './quantity-format.directive';

describe('QuantityFormatDirective', () => {
  let directive: QuantityFormatDirective;
  let elementRefMock: any;
  let rendererMock: any;
  let decimalPipeMock: any;

  beforeEach(() => {
    elementRefMock = {};
    rendererMock = {};
    decimalPipeMock = {};

    directive = new QuantityFormatDirective(elementRefMock, rendererMock, decimalPipeMock);
  });

  it('should create an instance', () => {
    expect(directive).toBeTruthy();
  });
});
