import { SplCategoryDto } from "src/app/models/spl-category-dto.model";
import { SplProductDto } from "src/app/models/spl-product-dto.model";
import { AccountHeaderDto } from "../../models/account-header-dto.model";
import { SplDto } from "../../models/spl-dto.model";

export class SplDtoMock {
  private splDto: SplDto = {
    id: 0,
    accountId: 0,
    splName: '',
    statusCode: '',
    effectiveDate: new Date(),
    splYear: 0,
    salesforceAccountId: '',
    accountTypeCode: '',
    corporatePhoenixId: 0,
    corporateSalesforceAccountId: '',
    splCategoryDtos: [],
    splProductDtos: [],
    accountHeaderDto: new AccountHeaderDto(),
    belowFloorPrice: '',
    projectedPercentOfTarget: 0,
    projectedTotalMarginAmount: 0,
    projectedTotalSalesAmount: 0,
    createdDate: new Date(),
    statusDescription: ''
  }

  withId(id: number): SplDtoMock {
    this.splDto.id = id;
    return this;
  }

  withAccountId(accountId: number): SplDtoMock {
    this.splDto.accountId = accountId;
    return this;
  }

  withSplName(splName: string): SplDtoMock {
    this.splDto.splName = splName;
    return this;
  }
  withStatusCode(statusCode: string): SplDtoMock {
    this.splDto.statusCode = statusCode;
    return this;
  }

  withEffectiveDate(effectiveDate: Date): SplDtoMock {
    this.splDto.effectiveDate = effectiveDate;
    return this;
  }

  withSplYear(splYear: number): SplDtoMock {
    this.splDto.splYear = splYear;
    return this;
  }

  withSalesforceAccountId(salesforceAccountId: string): SplDtoMock {
    this.splDto.salesforceAccountId = salesforceAccountId;
    return this;
  }

  withAccountTypeCode(accountTypeCode: string): SplDtoMock {
    this.splDto.accountTypeCode = accountTypeCode;
    return this;
  }

  withCorporatePhoenixId(corporatePhoenixId: number): SplDtoMock {
    this.splDto.corporatePhoenixId = corporatePhoenixId;
    return this;
  }

  withCorporateSalesforceAccountId(corporateSalesforceAccountId: string): SplDtoMock {
    this.splDto.corporateSalesforceAccountId = corporateSalesforceAccountId;
    return this;
  }

  withSplCategoryDtos(splCategoryDtos: SplCategoryDto[]): SplDtoMock {
    this.splDto.splCategoryDtos = splCategoryDtos;
    return this;
  }

  withSplProductDtos(splProductDtos: SplProductDto[]): SplDtoMock {
    this.splDto.splProductDtos = splProductDtos;
    return this;
  }

  withAccountHeaderDto(accountHeaderDto: AccountHeaderDto): SplDtoMock {
    this.splDto.accountHeaderDto = accountHeaderDto;
    return this;
  }

  withSplBelowFloorPrice(belowFloorPrice: string): SplDtoMock {
    this.splDto.belowFloorPrice = belowFloorPrice;
    return this;
  }

  withProjectedPercentOfTarget(projectedPercentOfTarget: number): SplDtoMock {
    this.splDto.projectedPercentOfTarget = projectedPercentOfTarget;
    return this;
  }

  withProjectedTotalMarginAmount(projectedTotalMarginAmount: number): SplDtoMock {
    this.splDto.projectedTotalMarginAmount = projectedTotalMarginAmount;
    return this;
  }

  withProjectedTotalSalesAmount(projectedTotalSalesAmount: number): SplDtoMock {
    this.splDto.projectedTotalSalesAmount = projectedTotalSalesAmount;
    return this;
  }

  withCreatedDate(createdDate: Date): SplDtoMock {
    this.splDto.createdDate = createdDate;
    return this;
  }

  withStatusDescription(statusDescription: string): SplDtoMock {
    this.splDto.statusDescription = statusDescription;
    return this;
  }

  model(): SplDto {
    return this.splDto;
  }
}