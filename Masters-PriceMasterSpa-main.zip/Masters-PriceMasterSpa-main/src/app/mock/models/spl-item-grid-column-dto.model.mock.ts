import { SplGridColumnDto } from "../../models/spl-item-grid-column-dto.model";

export class SplGridColumnDtoMock {
    private _data: SplGridColumnDto = {
        columnId: 0,
        title: '',
        name: '',
        frozen: true,
        isShown: false,
        isFieldDisabled: false,
        fieldType: '',
        format: '',
        position: 0
    };

    withColumnId(columnId: number): SplGridColumnDtoMock {
        this._data.columnId = columnId;
        return this;
    }

    withTitle(title: string): SplGridColumnDtoMock {
        this._data.title = title;
        return this;
    }

    withName(name: string): SplGridColumnDtoMock {
        this._data.name = name;
        return this;
    }

    withFrozen(frozen: boolean): SplGridColumnDtoMock {
        this._data.frozen = frozen;
        return this;
    }

    withIsShown(isShown: boolean): SplGridColumnDtoMock {
        this._data.isShown = isShown;
        return this;
    }

    withIsFieldDisabled(isFieldDisabled: boolean): SplGridColumnDtoMock {
        this._data.isFieldDisabled = isFieldDisabled;
        return this;
    }

    withFieldType(fieldType: string): SplGridColumnDtoMock {
        this._data.fieldType = fieldType;
        return this;
    }

    withFormat(format: string): SplGridColumnDtoMock {
        this._data.format = format;
        return this;
    }

    withPosition(position: number): SplGridColumnDtoMock {
        this._data.position = position;
        return this;
    }

    model(): SplGridColumnDto {
        return this._data;
    }
}