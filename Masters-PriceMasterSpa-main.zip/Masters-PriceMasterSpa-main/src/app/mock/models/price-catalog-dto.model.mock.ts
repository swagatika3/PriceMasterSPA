import { PriceCatalogDto } from "../../models/price-catalog-dto.model";

export class PriceCatalogDtoMock {
    private _data: PriceCatalogDto = {
        targetPrice: 0,
        floorPrice: 0,
        listPrice: 0
    };

    withTargetPrice(targetPrice: number): PriceCatalogDtoMock {
        this._data.targetPrice = targetPrice;
        return this;
    }

    withFloorPrice(floorPrice: number): PriceCatalogDtoMock {
        this._data.floorPrice = floorPrice;
        return this;
    }

    withListPrice(listPrice: number): PriceCatalogDtoMock {
        this._data.listPrice = listPrice;
        return this;
    }

    model(): PriceCatalogDto {
        return this._data;
    }
}