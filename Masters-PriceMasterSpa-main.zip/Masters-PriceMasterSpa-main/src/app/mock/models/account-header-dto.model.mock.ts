import { AccountHeaderDto } from "../../models/account-header-dto.model";

export class AccountHeaderDtoMock {
  private _data: AccountHeaderDto = {
    accountName: 'Pacific Copier & Computer',
    salesforceId: null,
    corporateName: null,
    corporateSalesforceId: null,
    corporateAccountId: null,
    accountType: null,
    hasCorporatePricing: false
  }

  withAccountName(accountName: string | null): AccountHeaderDtoMock {
    this._data.accountName = accountName;
    return this;
  }

  withSalesforceId(salesforceId: string | null): AccountHeaderDtoMock {
    this._data.salesforceId = salesforceId;
    return this;
  }

  withCorporateName(corporateName: string | null): AccountHeaderDtoMock {
    this._data.corporateName = corporateName;
    return this;
  }

  withCorporateSalesforceId(corporateSalesforceId: string | null): AccountHeaderDtoMock {
    this._data.corporateSalesforceId = corporateSalesforceId;
    return this;
  }

  withCorporateAccountId(corporateAccountId: number | null): AccountHeaderDtoMock {
    this._data.corporateAccountId = corporateAccountId;
    return this;
  }

  withaccountType(accountType: string | null): AccountHeaderDtoMock {
    this._data.accountType = accountType;
    return this;
  }
  withhasCorporatePricing(hasCorporatePricing: boolean): AccountHeaderDtoMock {
    this._data.hasCorporatePricing = hasCorporatePricing;
    return this;
  }

  model(): AccountHeaderDto {
    return this._data;
  }
}
