import { CategoryDto } from "../../models/category-dto.model";

export class CategoryDtoMock {
  private _data: CategoryDto = {
    id: 0,
    categoryNumber: '',
    categoryDescription: '',
    accountTypeCode: '',
    isSelected: false
  }

  withId(id: number): CategoryDtoMock {
    this._data.id = id;
    return this;
  }
  withCategoryNumber(categoryNumber: string): CategoryDtoMock {
    this._data.categoryNumber = categoryNumber
    return this;
  }

  withCategoryDescription(categoryDescription: string): CategoryDtoMock {
    this._data.categoryDescription = categoryDescription;
    return this;
  }

  withAccountTypeCode(accountTypeCode: string): CategoryDtoMock {
    this._data.accountTypeCode = accountTypeCode;
    return this;
  }

  withIsSelected(isSelected: boolean): CategoryDtoMock {
    this._data.isSelected = isSelected;
    return this;
  }

  model(): CategoryDto {
    return this._data;
  }
}
