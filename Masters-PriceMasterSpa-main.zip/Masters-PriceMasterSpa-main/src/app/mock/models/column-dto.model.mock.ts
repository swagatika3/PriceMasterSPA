import { Column } from "../../models/column-dto.model";

export class ColumnMock {
    private _data: Column = {
        columnName: '',
        position: 0
    }

    withColumnName(columnName: string): ColumnMock {
        this._data.columnName = columnName;
        return this;
    }

    withPosition(position: number): ColumnMock {
        this._data.position = position;
        return this;
    }

    model(): Column {
        return this._data;
    }
}