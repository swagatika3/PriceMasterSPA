import { IUITKSelectItemProps } from '@uitk/angular';

export class IUITKSelectItemPropsMock {
    private _data: IUITKSelectItemProps = {
        id: '',
        label: '',
        value: '',
        selected: false,
        disabled: false
    }

    withId(id: string): IUITKSelectItemPropsMock {
        this._data.id = id;
        return this;
    }

    withLabel(label: string): IUITKSelectItemPropsMock {
        this._data.label = label;
        return this;
    }

    withValue(value: any): IUITKSelectItemPropsMock {
        this._data.value = value;
        return this;
    }

    withSelected(selected?: boolean): IUITKSelectItemPropsMock {
        this._data.selected = selected;
        return this;
    }

    withDisabled(disabled?: boolean): IUITKSelectItemPropsMock {
        this._data.disabled = disabled;
        return this;
    }

    model(): IUITKSelectItemProps {
        return this._data;
    }
}