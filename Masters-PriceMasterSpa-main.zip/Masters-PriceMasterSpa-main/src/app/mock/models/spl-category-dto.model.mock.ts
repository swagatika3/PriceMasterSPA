import { SplCategoryDto } from "../../models/spl-category-dto.model";

export class SplCategoryDtoMock {
    private _data: SplCategoryDto = {
        categoryId: 0,
        appliedDiscount: 0
    }

    withCategoryId(categoryId: number): SplCategoryDtoMock {
        this._data.categoryId = categoryId;
        return this;
    }

    withAppliedDiscount(appliedDiscount: number): SplCategoryDtoMock {
        this._data.appliedDiscount = appliedDiscount;
        return this;
    }

    model(): SplCategoryDto {
        return this._data;
    }
}