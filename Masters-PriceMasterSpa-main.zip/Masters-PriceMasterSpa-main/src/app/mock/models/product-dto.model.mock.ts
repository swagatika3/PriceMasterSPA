import { OrderSummaryDto } from "src/app/models/order-summary-dto.model";
import { PriceCatalogDto } from "src/app/models/price-catalog-dto.model";
import { ProductDto } from "../../models/product-dto.model";

export class ProductDtoMock {
    private _data: ProductDto = {
        currentProductId: 0,
        priorProductId: 0,
        categoryId: 0,
        productCode: '',
        description: '',
        maxDiscountPercent: 0,

        effectiveDate: new Date(),
        editionYear: '',
        priceListCategory: '',
        priceListCategoryYear: '',
        priceCatalogDto: null,
        orderSummaryDto: null
    }

    withProductId(currentPoductId: number): ProductDtoMock {
        this._data.currentProductId = currentPoductId;
        return this;
    }

    withCategoryId(categoryId: number): ProductDtoMock {
        this._data.categoryId = categoryId;
        return this;
    }

    withProductCode(productCode: string): ProductDtoMock {
        this._data.productCode = productCode;
        return this;
    }

    withDescription(description: string): ProductDtoMock {
        this._data.description = description;
        return this;
    }

    withMaxDiscountPercent(maxDiscountPercent: number): ProductDtoMock {
        this._data.maxDiscountPercent = maxDiscountPercent;
        return this;
    }

    withEffectiveDate(effectiveDate: Date): ProductDtoMock {
        this._data.effectiveDate = effectiveDate;
        return this;
    }

    withEditionYear(editionYear: string): ProductDtoMock {
        this._data.editionYear = editionYear;
        return this;
    }

    withPriceListCategory(priceListCategory: string): ProductDtoMock {
        this._data.priceListCategory = priceListCategory;
        return this;
    }

    withPriceListCategoryYear(priceListCategoryYear: string): ProductDtoMock {
        this._data.priceListCategoryYear = priceListCategoryYear;
        return this;        
    }

    withPriceCatalogDto(priceCatalogDto: PriceCatalogDto | null): ProductDtoMock {
        this._data.priceCatalogDto = priceCatalogDto;
        return this;
    }

    withOrderSummaryDto(orderSummaryDto: OrderSummaryDto): ProductDtoMock {
        this._data.orderSummaryDto = orderSummaryDto;
        return this;
    }

    model(): ProductDto {
        return this._data;
    }
}