import { CreateSplDto } from "../../models/create-spl-dto.model";

export class CreateSplDtoMock {
    private _data: CreateSplDto = {
        accountId: 0,
        splYear: 0,
        categoryIds: []
    }

    withAccountId(accountId: number): CreateSplDtoMock {
        this._data.accountId = accountId;
        return this;
    }

    withCategoryIds(categoryIds: number[]): CreateSplDtoMock {
        this._data.categoryIds = categoryIds;
        return this;
    }

    model(): CreateSplDto {
        return this._data;
    }
}