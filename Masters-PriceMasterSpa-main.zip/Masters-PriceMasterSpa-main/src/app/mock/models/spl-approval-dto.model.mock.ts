import { SplApprovalDto } from "../../models/spl-approval-dto.model";

export class SplApprovalDtoMock {
    private _data: SplApprovalDto = {
        approvalLevel: '',
        defaultApprover: '',
        approvedBy: '',
        approvedDate: new Date()
    }

    withApprovalLevel(approvalLevel: string): SplApprovalDtoMock {
        this._data.approvalLevel = approvalLevel;
        return this;
    }

    withDefaultApprover(defaultApprover: string): SplApprovalDtoMock {
        this._data.defaultApprover = defaultApprover;
        return this;
    }

    withApprovedBy(approvedBy: string): SplApprovalDtoMock {
        this._data.approvedBy = approvedBy;
        return this;
    }

    withApprovedDate(approvedDate: Date): SplApprovalDtoMock {
        this._data.approvedDate = approvedDate;
        return this;
    }

    model(): SplApprovalDto {
        return this._data;
    }
}