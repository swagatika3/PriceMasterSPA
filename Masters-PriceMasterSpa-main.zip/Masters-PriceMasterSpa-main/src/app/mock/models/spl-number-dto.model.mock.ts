import { SplNumberDto } from "../../models/spl-number-dto.model";
export class SplNumberDtoMock {
  private _data: SplNumberDto = {
    splNumber : 0
  }

  withSplNumber(splNumber: number) {
    this._data.splNumber = splNumber;
    return this;
  }

  model(): SplNumberDto {
    return this._data;
  }
}
