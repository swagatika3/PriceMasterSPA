import { PriceListCategoriesDto } from "../../models/price-list-categories-dto.model";

export class PriceListCategoriesDtoMock {
    private _data: PriceListCategoriesDto = {
        isNewPriceListCategory: false,
        priceListCategoryId: 0,
        priceListCategory: '',
        specifiedDiscount: 0
    }

    withIsNewPriceListCategory(isNewPriceListCategory: boolean): PriceListCategoriesDtoMock {
        this._data.isNewPriceListCategory = isNewPriceListCategory;
        return this;
    }

    withPriceListCategoryId(priceListCategoryId: number): PriceListCategoriesDtoMock {
        this._data.priceListCategoryId = priceListCategoryId;
        return this;
    }

    withPriceListCategory(priceListCategory: string): PriceListCategoriesDtoMock {
        this._data.priceListCategory = priceListCategory;
        return this;
    }

    withSpecifiedDiscount(specifiedDiscount: number): PriceListCategoriesDtoMock {
        this._data.specifiedDiscount = specifiedDiscount;
        return this;
    }

    model(): PriceListCategoriesDto {
        return this._data;
    }
}