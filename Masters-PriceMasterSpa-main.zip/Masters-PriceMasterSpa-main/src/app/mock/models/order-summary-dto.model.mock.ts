import { OrderSummaryDto } from "../../models/order-summary-dto.model";

export class OrderSummaryDtoMock {
    private _data: OrderSummaryDto = {
        unitsSold: 0,
        averageDiscount: 0
    }

    withUnitsSold(unitsSold: number): OrderSummaryDtoMock {
        this._data.unitsSold = unitsSold;
        return this;
    }

    withAverageDiscount(averageDiscount: number): OrderSummaryDtoMock {
        this._data.averageDiscount = averageDiscount;
        return this;
    }

    model(): OrderSummaryDto {
        return this._data;
    }
}