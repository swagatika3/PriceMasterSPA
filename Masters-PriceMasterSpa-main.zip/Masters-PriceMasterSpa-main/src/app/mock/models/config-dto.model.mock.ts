import { ConfigDto } from "../../models/config-dto.model";

export class ConfigDtoMock {
  private _data: ConfigDto ={
    spaUrl : '',
    apiUrl : '',
  }

  withSpaUrl(spaUrl: string): ConfigDtoMock {
    this._data.spaUrl = spaUrl
    return this;
  }

  withApiUrl(apiUrl: string): ConfigDtoMock {
    this._data.apiUrl = apiUrl;
    return this;
  }

  model(): ConfigDto {
    return this._data;
  }
}
