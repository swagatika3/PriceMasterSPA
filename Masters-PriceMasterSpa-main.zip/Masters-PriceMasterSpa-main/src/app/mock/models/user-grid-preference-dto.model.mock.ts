import { Column } from "../../models/column-dto.model";
import { UserGridPreferenceDto } from "../../models/user-grid-preference-dto.model";

export class UserGridPreferenceDtoMock {
    private _data: UserGridPreferenceDto = {
        userLogin: '',
        gridName: '',
        columns: []
    }

    withUserLogin(userLogin: string): UserGridPreferenceDtoMock {
        this._data.userLogin = userLogin;
        return this;
    }

    withGridName(gridName: string): UserGridPreferenceDtoMock {
        this._data.gridName = gridName;
        return this;
    }

    withColumns(columns: Column[]): UserGridPreferenceDtoMock {
        this._data.columns = columns;
        return this;
    }

    model(): UserGridPreferenceDto {
        return this._data;
    }
}