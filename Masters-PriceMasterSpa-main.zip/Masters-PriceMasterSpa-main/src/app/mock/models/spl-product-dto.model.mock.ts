import { OrderSummaryDto } from "../../models/order-summary-dto.model";
import { PriceCatalogDto } from "../../models/price-catalog-dto.model";
import { ProductDto } from "../../models/product-dto.model";
import { SplProductDto } from "../../models/spl-product-dto.model";

export class SplProductDtoMock {
    private _data: SplProductDto = {
        productId: 0,
        splPrice: 0,
        splDiscount: 0,
        priorSplPrice: 0,
        priorSplDiscount: 0,
        effectiveDate: new Date(),
        appliedCategoryDiscount: 0,
        quantity: 0,
        currentProductDto: new ProductDto(),
        priorProductDto: new ProductDto()
    }

    withProductId(productId: number): SplProductDtoMock {
        this._data.productId = productId;
        return this;
    }

    withSplPrice(splPrice: number): SplProductDtoMock {
        this._data.splPrice = splPrice;
        return this;
    }

    withSplDiscount(splDiscount: number): SplProductDtoMock {
        this._data.splDiscount = splDiscount;
        return this;
    }

    withPriorSplPrice(priorSplPrice: number): SplProductDtoMock {
        this._data.priorSplPrice = priorSplPrice;
        return this;
    }

    withPriorSplDiscount(priorSplDiscount: number): SplProductDtoMock {
        this._data.priorSplDiscount = priorSplDiscount;
        return this;
    }

    withEffectiveDate(effectiveDate: Date): SplProductDtoMock {
        this._data.effectiveDate = effectiveDate;
        return this;
    }

    withAppliedCategoryDiscount(appliedCategoryDiscount: number): SplProductDtoMock {
        this._data.appliedCategoryDiscount = appliedCategoryDiscount;
        return this;
    }

    withQuantity(quantity: number): SplProductDtoMock {
        this._data.quantity = quantity;
        return this;
    }

    withCurrentProductDto(currentProductDto: ProductDto): SplProductDtoMock {
        this._data.currentProductDto = currentProductDto;
        return this;
    }

    withPriorProductDto(priorProductDto: ProductDto): SplProductDtoMock {
        this._data.priorProductDto = priorProductDto;
        return this;
    }

    model(): SplProductDto {
        return this._data;
    }
}