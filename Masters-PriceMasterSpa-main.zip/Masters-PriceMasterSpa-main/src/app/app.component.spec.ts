import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;

  beforeAll(() => {
    component = new AppComponent();
  });


  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it(`should have as title 'PriceMasterSpa'`, () => {
    expect(component.title).toEqual('PriceMasterSpa');
  });

  it(`should have as title 'PriceMasterSpa'`, () => {
    expect(component.title).toEqual('PriceMasterSpa');
  });

  //it('should render title', () => {
  //  const fixture = TestBed.createComponent(AppComponent);
  //  fixture.detectChanges();
  //  const compiled = fixture.nativeElement as HTMLElement;
  //  expect(compiled.querySelector('.content span')?.textContent).toContain('PriceMasterSpa app is running!');
  //});
});
