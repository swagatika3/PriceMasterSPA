import { APP_INITIALIZER, NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { UITKAutocompleteModule, UITKCheckboxModule, UITKDatePickerModule, UITKDialogModule, UITKDropdownModule, UITKFieldsetModule, UITKFormFieldService, UITKInputModule, UITKInputService, UITKLoadingIndicatorModule, UITKNavigationModule, UITKNotificationModule, UITKPageNotificationModule, UITKPaginationModule, UITKPanelModule, UITKProgressBarModule, UITKRadioGroupModule, UITKSelectModule, UITKTabbedPanelsModule, UITKTableFeaturesModule, UITKTableModule, UITKTextAreaModule, UITKTooltipModule, UITKFooterModule } from '@uitk/angular';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenuComponent } from './components/menu/menu.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HomeComponent } from './components/home/home.component';
import { SplCreateComponent } from './components/spl-create/spl-create.component';
import { SplBelowFloorPriceComponent } from './components/spl-edit/spl-below-floor-price/spl-below-floor-price.component';
import { AccountIdCloneDialogComponent } from './dialogs/account-id-clone-dialog/account-id-clone-dialog.component';
import { SplSummaryComponent } from './components/spl-edit/spl-summary/spl-summary.component';
import { HttpClientModule } from '@angular/common/http';
import { ConfigService } from './services/config.service';
import { LoaderComponent } from './components/loader/loader.component';
import { SplItemGridComponent } from './components/spl-edit/spl-item-grid/spl-item-grid.component';
import { CommonModule, CurrencyPipe, DatePipe, DecimalPipe, PercentPipe } from '@angular/common';
import { PriceListCategoriesSectionComponent } from './components/spl-edit/price-list-categories-section/price-list-categories-section.component';
import { TwoRecordsInSingleRowPipe } from './pipes/two-records-in-single-row.pipe';
import { SplEditComponent } from './components/spl-edit/spl-edit.component';
import { SplFooterComponent } from './components/spl-edit/spl-footer/spl-footer.component';
import { FilterItemgridBasedonPricelistcategoryPipe } from './pipes/filter-itemgrid-basedon-pricelistcategory.pipe';
import { FilterItemgridBasedonItemnumberPipe } from './pipes/filter-itemgrid-basedon-itemnumber.pipe';
import { DiscountFormatDirective } from './directives/discount-format.directive';
import { PriceFormatDirective } from './directives/price-format.directive';
import { QuantityFormatDirective } from './directives/quantity-format.directive';
import { ApprovalSectionComponent } from './components/spl-edit/approval-section/approval-section.component';
import { ProjectionsComponent } from './components/spl-edit/projections/projections.component';

@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    HomeComponent,
    SplCreateComponent,
    SplBelowFloorPriceComponent,
    AccountIdCloneDialogComponent,
    SplSummaryComponent,
    SplItemGridComponent,
    AccountIdCloneDialogComponent,
    LoaderComponent,
    PriceListCategoriesSectionComponent,
    TwoRecordsInSingleRowPipe,
    SplEditComponent,
    SplFooterComponent,
    FilterItemgridBasedonPricelistcategoryPipe,
    FilterItemgridBasedonItemnumberPipe,
    DiscountFormatDirective,
    PriceFormatDirective,
    QuantityFormatDirective,
    ApprovalSectionComponent,
    ProjectionsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    UITKInputModule,
    UITKNavigationModule,
    UITKTableModule,
    UITKFieldsetModule,
    UITKSelectModule,
    UITKPanelModule,
    UITKTableFeaturesModule,
    UITKPaginationModule,
    UITKInputModule,
    UITKDropdownModule,
    UITKDialogModule,
    UITKPageNotificationModule,
    UITKProgressBarModule,
    UITKTextAreaModule,
    UITKDatePickerModule,
    UITKRadioGroupModule,
    UITKCheckboxModule,
    UITKTooltipModule,
    UITKNotificationModule,
    UITKTabbedPanelsModule,
    UITKDatePickerModule,
    UITKLoadingIndicatorModule,
    UITKFooterModule,
    NgbModule,
    HttpClientModule,
    UITKAutocompleteModule,
    ReactiveFormsModule, 
    CommonModule
  ],
  providers: [
    UITKFormFieldService,
    UITKInputService,
    CurrencyPipe,
    DecimalPipe,
    DatePipe,
    PercentPipe,
    ConfigService, {
      provide: APP_INITIALIZER, 
      useFactory: (config: ConfigService) => () => config.load(),
      deps: [ConfigService], multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
