import { Pipe, PipeTransform } from '@angular/core';
import { SplProductDto } from '../models/spl-product-dto.model';

@Pipe({
  name: 'filterItemgridBasedonItemnumber'
})

export class FilterItemgridBasedonItemnumberPipe implements PipeTransform {
  transform(splProductDtos: SplProductDto[], searchItem: string): SplProductDto[] {
    return searchItem === '' ? splProductDtos : splProductDtos.filter(sp => sp.currentProductDto.productCode === searchItem);
  }
}
