import { Pipe, PipeTransform } from '@angular/core';
import { IUITKSelectItemProps } from '@uitk/angular';
import { SplProductDto } from '../models/spl-product-dto.model';

@Pipe({
  name: 'filterItemgridBasedonPricelistcategory'
})

export class FilterItemgridBasedonPricelistcategoryPipe implements PipeTransform {
  transform(splProductDtos: SplProductDto[], selectedPriceListCategory: IUITKSelectItemProps): SplProductDto[] {
    return selectedPriceListCategory === undefined || selectedPriceListCategory.label === 'Select' ? splProductDtos : splProductDtos.filter(sp => sp.currentProductDto.categoryId === Number(selectedPriceListCategory.id));
  }
}