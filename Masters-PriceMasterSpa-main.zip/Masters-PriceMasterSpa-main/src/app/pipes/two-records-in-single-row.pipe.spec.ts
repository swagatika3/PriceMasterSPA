import { TwoRecordsInSingleRowPipe } from './two-records-in-single-row.pipe';

describe('TwoRecordsInSingleRowPipe', () => {
  it('create an instance', () => {
    const pipe = new TwoRecordsInSingleRowPipe();
    expect(pipe).toBeTruthy();
  });
});
