import { FilterItemgridBasedonItemnumberPipe } from './filter-itemgrid-basedon-itemnumber.pipe';

describe('FilterItemgridBasedonItemnumberPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterItemgridBasedonItemnumberPipe();
    expect(pipe).toBeTruthy();
  });
});
