import { FilterItemgridBasedonPricelistcategoryPipe } from './filter-itemgrid-basedon-pricelistcategory.pipe';

describe('FilterItemgridBasedonPricelistcategoryPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterItemgridBasedonPricelistcategoryPipe();
    expect(pipe).toBeTruthy();
  });
});
