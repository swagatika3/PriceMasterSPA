export enum SplMode {
    CreateSpl,
    CreateNextYearSpl,
    EditSpl
  }