export enum Mode {
  View,
  Edit,
  Add,
  Wait
}
