export class ConfigDto {
  spaUrl = '';
  apiUrl = '';
}
