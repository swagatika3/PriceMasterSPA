export class CategoryDto {
  id = 0;
  categoryNumber = '';
  categoryDescription = '';
  accountTypeCode = '';

  // The following properties are used for binding
  isSelected = false;
}
