export class OrderSummaryDto {
    unitsSold = 0;
    averageDiscount = 0;
}