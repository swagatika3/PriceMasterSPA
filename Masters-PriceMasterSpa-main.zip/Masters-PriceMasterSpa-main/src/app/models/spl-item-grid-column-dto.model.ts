export class SplGridColumnDto {
  columnId = 0;
  title = '';
  name = '';
  frozen = true;
  isShown = false;
  //UI Property
  isFieldDisabled = false;
  fieldType = '';
  format = '';
  position = 0;
}