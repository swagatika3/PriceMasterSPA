import { Column } from "./column-dto.model";

export class UserGridPreferenceDto {
    userLogin = '';
    gridName = '';
    columns: Column[] = [];
}