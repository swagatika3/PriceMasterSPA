export class AccountHeaderDto {
  accountName: string | null = null;
  salesforceId: string | null = null;
  corporateName: string | null = null;
  corporateSalesforceId: string | null = null;
  corporateAccountId: number | null = null;
  accountType: string | null = null;
  hasCorporatePricing = false;
}
