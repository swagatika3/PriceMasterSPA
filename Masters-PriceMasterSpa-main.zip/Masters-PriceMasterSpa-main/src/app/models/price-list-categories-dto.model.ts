export class PriceListCategoriesDto {
    isNewPriceListCategory = false;
    priceListCategoryId = 0;
    priceListCategory = '';
    specifiedDiscount = 0;
}