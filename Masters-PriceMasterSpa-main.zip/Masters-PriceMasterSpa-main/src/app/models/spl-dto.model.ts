import { AccountHeaderDto } from "./account-header-dto.model";
import { SplProductDto } from "./spl-product-dto.model";
import { SplCategoryDto } from "./spl-category-dto.model";

export class SplDto {
  id = 0;
  splName = '';
  createdDate = new Date();
  effectiveDate: Date | null = null;
  splYear = 0;
  accountId = 0;
  statusCode = '';
  salesforceAccountId: string | null = null;
  accountTypeCode = '';
  corporatePhoenixId: number | null = null;
  corporateSalesforceAccountId: string | null = null;  
  splCategoryDtos: SplCategoryDto[] = [];
  splProductDtos: SplProductDto[] = [];
  accountHeaderDto: AccountHeaderDto = new AccountHeaderDto();

  // The follow fields are for binding purposes only.
  belowFloorPrice = '';
  projectedPercentOfTarget = 0;
  projectedTotalSalesAmount = 0;
  projectedTotalMarginAmount = 0;
  statusDescription = '';
}
