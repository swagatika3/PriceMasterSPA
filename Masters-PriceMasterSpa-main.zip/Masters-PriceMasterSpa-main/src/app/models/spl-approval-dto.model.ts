export class SplApprovalDto {
    approvalLevel = '';
    defaultApprover = '';
    approvedBy = '';
    approvedDate: Date | null = new Date();
}