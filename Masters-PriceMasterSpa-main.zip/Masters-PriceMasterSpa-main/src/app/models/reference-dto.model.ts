import { CategoryDto } from "./category-dto.model";
import { ProductDto } from "./product-dto.model";

export class ReferenceDto {
    productDtos: ProductDto[] = [];
    categoryDtos: CategoryDto[] = [];
}