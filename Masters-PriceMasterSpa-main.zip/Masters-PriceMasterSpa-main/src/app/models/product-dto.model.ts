import { OrderSummaryDto } from "./order-summary-dto.model";
import { PriceCatalogDto } from "./price-catalog-dto.model";

export class ProductDto {
    currentProductId = 0;
    priorProductId = 0;
    categoryId: number | null = null;
    productCode = '';
    description = '';
    maxDiscountPercent = 0;
    effectiveDate: Date = new Date();
    editionYear: string | null = null;
    priceListCategory = '';
    priceListCategoryYear: string | null = null;
    priceCatalogDto: PriceCatalogDto | null = null;
    orderSummaryDto: OrderSummaryDto | null = null;
}