export class SplNumberDto {
    splNumber = 0;
}