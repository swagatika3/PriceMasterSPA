export class PriceCatalogDto {
    targetPrice = 0;
    floorPrice = 0;
    listPrice = 0;
}