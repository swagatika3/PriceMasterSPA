import { ProductDto } from "./product-dto.model";

export class SplProductDto {
    productId = 0;
    splPrice = 0;
    splDiscount = 0;
    priorSplPrice = 0;
    priorSplDiscount = 0;
    effectiveDate: Date = new Date();
    appliedCategoryDiscount = 0;
    quantity = 0;
    currentProductDto: ProductDto = new ProductDto();
    priorProductDto: ProductDto | null = null;
}