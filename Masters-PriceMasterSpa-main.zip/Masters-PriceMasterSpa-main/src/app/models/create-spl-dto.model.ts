export class CreateSplDto {
    accountId = 0;
    categoryIds: number[] = [];
    splYear = 0;
}