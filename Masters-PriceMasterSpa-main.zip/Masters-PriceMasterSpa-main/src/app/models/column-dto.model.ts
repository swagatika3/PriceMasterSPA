export class Column {
    columnName = '';
    position = 0;
}