export class SplCategoryDto {
    categoryId = 0;
    appliedDiscount = 0;
}